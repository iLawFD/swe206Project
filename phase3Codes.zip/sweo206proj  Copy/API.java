package sweo206proj;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class API {
    public static void main(String[] args) {
        String endpoint = "https://us-central1-swe206-221.cloudfunctions.net/app/UserSignIn";
        Scanner sc = new Scanner(System.in);
        System.out.println("Write your user name then your password:");
        String username = sc.nextLine();
        String password = sc.nextLine();
        sc.close();

        try {
            String urlStr = endpoint + "?username=" + username + "&password=" + password;
            URL url = new URL(urlStr);

            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("GET");

            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            StringBuilder response = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

            int responseCode = connection.getResponseCode();

            System.out.println("Response Code: " + responseCode);
            System.out.println("Response Content: " + response.toString());

            System.out.println(response.toString().toLowerCase().contains("admin"));

            connection.disconnect();
        } catch (IOException e) {
            System.out.println("Not");
        }
    }
}
