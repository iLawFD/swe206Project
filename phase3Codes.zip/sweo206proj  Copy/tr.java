package sweo206proj;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

public class tr {


    public static void main(String[] args) throws IOException {




}}


