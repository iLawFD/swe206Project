package sweo206proj;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DialogPane;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.Window;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Optional;
import java.util.Properties;

public class controller2 {



    @FXML
    private TextField usernameF;

    @FXML
    private TextField emailF;

    @FXML
    private TextField passwordF;

    @FXML
    private TextField tournmentF;

    @FXML
    protected void backAct(ActionEvent event) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("s2Admin.fxml"));


        Node node = (Node) event.getSource();

        Window win = ((Scene) node.getScene()) .getWindow();
        if (win != null) {
            Scene scene = win.getScene();
            if (scene != null) {
                javafx.stage.Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                FXMLLoader fxmlLoader2 = new FXMLLoader(Main.class.getResource("s2Admin.fxml"));



                Scene scene2 = new Scene(fxmlLoader2.load(), 900, 600);
                stage.setScene(scene2);
            }
        }
        
        
    }
    @FXML
    protected void createAct() throws IOException {

        String username = usernameF.getText();
        String email = emailF.getText();
        String passS = passwordF.getText();
        String name = tournmentF.getText();

        boolean notEmpty = true;
        notEmpty = Main.emptyInput(username , email , passS);
        boolean valid = true;
        valid = Main.validInput(username , email , passS);

        if(notEmpty) {
            if (valid) {
                int password = Integer.valueOf(passS);
                int userName= Integer.valueOf(username);
                    //System.out.println("add");
                    Student student = new Student(email, userName, password);

                    // with tournament
                   // StudentProfile result =  Main.addStudent(student);
                    Tournament resultant = null;
                         resultant = Main.tournamentExsist(name);
                         if(resultant== null){

                            // System.out.println("here");
                             Alert alert = new Alert(Alert.AlertType.WARNING);

                             alert.setTitle("Input Error");
                             alert.setHeaderText("The given tournment does not exsist  ");
                             alert.setContentText("Please give the name of exsisting tournment");
                             alert.showAndWait();
                             return;

                         }

                        if(resultant.isFinished()){
                            Alert alert = new Alert(Alert.AlertType.WARNING);
                            alert.setTitle("Input Error");
                            alert.setHeaderText(" The given tournment is done ");
                            alert.setContentText("Please try another tournment");
                            alert.showAndWait();
                            return ;





                    }
                StudentProfile result = Main.studentIsReg(student);
                StudentProfile p = Main.studentIsReg(student);
                Tournament t = resultant;
                if( result  == null)
                    return;



               // System.out.println("re is" + result);
                   // System.out.println(result);
                    if(result == null){ // it has just been created
                        if(name.equals("")){

                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                            alert.setTitle("Mission accomplished ");
                            alert.setHeaderText("The profile has been created ");
                            alert.setContentText("You can search for the student by pressing the back button and search ");
                            alert.showAndWait();


                            String smtpServer = "smtp.office365.com";
                            int smtpPort = 587;

                            // Sender and recipient email addresses
                            String senderEmail = "tournmenteofficial@outlook.com";
                            //String recipientEmail = "ggforever111@gmail.com";


                            String recipientEmail = "Abdulmjeed.alothman222@gmail.com";

                            // Sender's credentials
                            String username1 = "tournmenteofficial@outlook.com";
                            String password1 = "1234--QWer";

                            // Email content
                            String subject = "Tourrnmente reg ";
                            String body = "You have been added to the tournemnete!.";

                            // SMTP server properties
                            Properties props = new Properties();
                            props.put("mail.smtp.auth", "true");
                            props.put("mail.smtp.starttls.enable", "true");
                            props.put("mail.smtp.host", smtpServer);
                            props.put("mail.smtp.port", smtpPort);

                            // Create an authenticator with the sender's credentials
                            Authenticator authenticator = new Authenticator() {
                                @Override
                                protected PasswordAuthentication getPasswordAuthentication() {
                                    return new PasswordAuthentication(username1, password1);
                                }
                            };

                            // Create a session with the SMTP server
                            Session session = Session.getInstance(props, authenticator);

                            try {
                                // Create a new email message
                                Message message = new MimeMessage(session);
                                message.setFrom(new InternetAddress(senderEmail));
                                message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
                                message.setSubject(subject);
                                message.setText(body);

                                // Send the email
                                Transport.send(message);

                                System.out.println("Email sent successfully!");
                            } catch (MessagingException e) {
                                e.printStackTrace();
                            }
                            return;





                        }
                        else{

                            System.out.println("ha?");

                            //result.getTournments().add();

                            // show message that the profile has been created with the given tournamnet


                           // System.out.println("ent?");
                            if(t.isIndv() == true){
                               // System.out.println("Ha??");
                               // System.out.println("e1");
                                System.out.println("INDV?");
                                Alert alert = new Alert(Alert.AlertType.INFORMATION);

                                alert.setTitle("Mission accomplished ");
                                alert.setHeaderText("The profile has been created with the tournment ");
                                alert.setContentText("You can search for the sutdent by pressing the back button and search ");
                                alert.showAndWait();
                                t.getPlayers().add(p.getStudent());
                                p.getTournments().add(t);
                                Main.addTournment2(t);
                                Main.addProfile(p);

                                return;


                            }


                            //tested up until here
                            else{
                                //System.out.println("shof2");
                                //System.out.println("e2");

                                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                                DialogPane dialogPane = alert.getDialogPane();
                                TextField inputField = new TextField();
                                dialogPane.setContent(inputField);
                                Optional<ButtonType> re = alert.showAndWait();

                                //System.out.println("this ent?");
                                System.out.println(re.get() == ButtonType.OK);
                                if (re.get() == ButtonType.OK) {
                                    String input = inputField.getText();
                                    Team flag= t.checkTeamName(input);
                                    if(flag!= null){

                                        ArrayList<Participant> teams = t.getPlayers();
                                        for(int i= 0 ;i <teams.size() ; i++){

                                            Team team = (Team) teams.get(i);

                                           ArrayList<Student> students = team.getStudents();
                                            for(int j= 0 ;j <students.size() ; j++){

                                                if(p.getStudent().getUserName().equals(students.get(j).getUserName())){


                                                    Alert alert2 = new Alert(Alert.AlertType.WARNING);
                                                    alert2.setTitle("Error ");
                                                    alert2.setHeaderText(" Student can not be added to the same tournment ");


                                                }

                                            }



                                        }

                                        flag.getStudents().add(p.getStudent());

                                        //System.out.println("Ent");

                                        Alert alert2 = new Alert(Alert.AlertType.INFORMATION);
                                        alert2.setTitle("Mission accomplished ");
                                        alert2.setHeaderText("The profile has been created and student is added to the team ");
                                        alert2.setContentText("You can search for the student by pressing the back button and search ");

                                        p.getTournments().add(t);
                                        Main.addTournment2(t);
                                        Main.addProfile(p);
                                        return;








                                    }
                                    else{

                                        System.out.println("Ent2?");
                                        Alert al =  new Alert(Alert.AlertType.WARNING);

                                        al.setTitle("Input Error");
                                        al.setHeaderText("the given input is wrong! or it the team is not in  " + t.getName() + " ");
                                        al.setContentText("Please make sure to write a corrcet team name");
                                        al.showAndWait();
                                        return ;

                                    }
                                    //t.checkTeam()
                                    // Do something with the input
                                }
                                //System.out.println(re.get()==ButtonType.OK);




                            }





                            // add tournment to profile


                        }


                    }
                    else{

                        if(name.equals("")){

                            Alert alert = new Alert(Alert.AlertType.INFORMATION);

                            alert.setTitle("Error! ");
                            alert.setHeaderText("The profile already exsist ");
                            alert.setContentText(" Please provide a unique email and name for the student ");
                            alert.showAndWait();
                            return;

                        }
                        else{
                            if(t.isIndv()){
                                System.out.println("user " + userName);
                                for(int i = 0 ; i <t.getPlayers().size() ; i ++){

                                    if(((Student)t.getPlayers().get(i)).getUserName() == userName){

                                        Alert alert2 = new Alert(Alert.AlertType.WARNING);
                                        alert2.setTitle("Error ");
                                        alert2.setHeaderText(" Student can not be added to the same tournment ");
                                        alert2.showAndWait();
                                        return;


                                    }


                                }

                              //  System.out.println("e1");
                                Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                                alert1.setTitle("Mission accomplished ");
                                alert1.setHeaderText("The tournment has been added to the profile");
                                alert1.setContentText("You can search for the student by pressing the back button and search ");
                                alert1.showAndWait();

                                t.getPlayers().add(p.getStudent());
                                result.getTournments().add(t);
                                Main.addTournment2(t);
                                Main.addProfile(result);
                                //Main.addTournment2()



                            }


                            else{

                              //  System.out.println("e2");

                                Alert alert1 = new Alert(Alert.AlertType.INFORMATION);

                                DialogPane dialogPane = alert1.getDialogPane();
                                dialogPane.setHeaderText("Enter team name");
                                dialogPane.setContentText("Enter team name");
                                TextField inputField = new TextField();
                                dialogPane.setContent(inputField);

                                Optional<ButtonType> re = alert1.showAndWait();

                                //System.out.println(re.get() == ButtonType.OK);
                                if  (re.get() == ButtonType.OK) {

                                   // System.out.println("e1");
                                    String input = inputField.getText();
                                    Team flag= t.addToTeam(input, student);

                                    if(flag != null){

                                     //   System.out.println("hna");





                                        ArrayList<Participant> teams  =t.getPlayers();
                                        for(int i= 0 ;i <teams.size() ; i++){

                                            Team team = (Team) teams.get(i);

                                            ArrayList<Student> students = team.getStudents();
                                            for(int j= 0 ;j <students.size() ; j++){

                                                if(p.getStudent().getUserName().equals(students.get(j).getUserName())){


                                                    Alert alert2 = new Alert(Alert.AlertType.WARNING);
                                                    alert2.setTitle("Error ");
                                                    alert2.setHeaderText(" Student can not be added to the same tournment ");


                                                }

                                            }



                                        }



                                        Alert alert2 = new Alert(Alert.AlertType.INFORMATION);

                                        alert2.setTitle("Mission accomplished ");
                                        alert2.setHeaderText("The profile has been created and student is added to the team ");
                                        alert2.setContentText("You can search for the student by pressing the back button and search ");

                                        //flag.getStudents().add(student);
                                        result.getTournments().add(t);
                                        Main.addTournment2(t);

                                        Main.addProfile(result);
                                        //Main.addStudent();



                                    }
                                    else{


                                        Alert al =  new Alert(Alert.AlertType.WARNING);
                                        al.setTitle("Input Error");
                                        al.setHeaderText("the given input is wrong! or it the team is not in  " + t.getName() + " ");
                                        al.setContentText("Please make sure to write a corrcet team name");
                                        al.showAndWait();
                                        return;

                                    }
                                  //  System.out.println(re.get() == ButtonType.OK);

                                }
                            }



                        }


                    }



                } else {
                Alert alert = new Alert(Alert.AlertType.WARNING);

                alert.setTitle("Input Error");
                alert.setHeaderText("One more or more of the given input is wrong! ");
                alert.setContentText("Please note that email must conatin @ and the password must consist of 4 digits ");
                alert.showAndWait();
                }

            } else
            {


                Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Input Error");
                alert.setHeaderText("One or more of the fields are empty! ");
                alert.setContentText("Please fill all of the information before pressing create account");
                alert.showAndWait();

            }


        }



}
