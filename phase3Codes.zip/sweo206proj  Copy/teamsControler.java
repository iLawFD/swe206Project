package sweo206proj;




import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

public class teamsControler {

    @FXML
    TextField teamF;
    @FXML
    TextField tournmentF;
    @FXML
    TextField studentsF;

    @FXML
    Button submitB;



//add team

    @FXML
    protected void backAct(ActionEvent event) throws IOException {

       // FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("s2Admin.fxml"));


        Node node = (Node) event.getSource();

        Window win = ((Scene) node.getScene()) .getWindow();
        if (win != null) {
            Scene scene = win.getScene();
            if (scene != null) {
                javafx.stage.Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                FXMLLoader fxmlLoader2 = new FXMLLoader(Main.class.getResource("s2Admin.fxml"));



                Scene scene2 = new Scene(fxmlLoader2.load(), 900, 600);
                stage.setScene(scene2);
            }
        }


    }
    @FXML
    protected  void score() throws IOException {

        String team = teamF.getText();
        String tournment = tournmentF.getText();
        String students = studentsF.getText();
        if((team.isEmpty()&& tournment.isEmpty() && students.isEmpty())){


            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Input Error");
            alert.setHeaderText("One or more of the fields are empty! ");
            alert.setContentText("Please fill all of the information before pressing create account");
            alert.showAndWait();



        }
        else{
            Tournament t = Main.tournamentExsist(tournment);


            if(t != null){



                if(t.isIndv()){

                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Tournment Error");
                    alert.setHeaderText("The given tournment is not for teams! ");
                    alert.setContentText("Please write a team based tournemnte");
                    alert.showAndWait();

                    return;



                }

                if(t.isFinished()){

                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Tournment Error");
                    alert.setHeaderText("The given tournment is done ");
                    alert.setContentText("Please write a tournemnte that is noy finished");
                    alert.showAndWait();

                    return;


                }

                Team t1 = t.checkTeam(team);



                if(t1== null ){

                    t1 = new Team( new ArrayList<>(), team);

                    String[] userNames = students.split(",");
                    ArrayList<Student> sts = new ArrayList<>();

                    for(int i =0 ; i <userNames.length ; i ++){


                        //System.out.println(userNames[i]);
                        StudentProfile result = Main.searchByUserName(Integer.parseInt(userNames[i]));
                        if(result != null){


                            Student st = result.getStudent();
                                if(t1.getStudents() != null){
                                    for(int j = 0 ; j < t1.getStudents().size() ; j ++){

                                        if(t1.getStudents().get(j).getUserName().equals(st.getUserName())){

                                            Alert alert = new Alert(Alert.AlertType.ERROR);
                                            alert.setTitle("Team Error");
                                            alert.setHeaderText("Student can not be added to the same team! ");
                                            alert.setContentText("Please write a valid input ");
                                            alert.showAndWait();
                                        }

                                    }
                                }

                                for(int z = 0 ; z < t.getPlayers().size() ; z ++) {
                                    Team tm =(Team)t.getPlayers().get(z);
                                    if (tm.getStudents() != null) {
                                        for (int b = 0; b < tm.getStudents().size(); b++) {

                                            if (tm.getStudents().get(b).getUserName().equals(st.getUserName())) {
                                                Alert alert = new Alert(Alert.AlertType.ERROR);
                                                alert.setTitle("Team Error");
                                                alert.setHeaderText("Student can not be added to the same tournment! ");
                                                alert.setContentText("Please write a valid input ");
                                                alert.showAndWait();
                                                return;

                                            }
                                        }

                                    }
                                }


                            sts.add(st);


                        }
                        else{

                            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.setTitle("Team Error");
                            alert.setHeaderText("The "+ (i+1)+ " Student is not there ");
                            alert.setContentText("Please write a valid student");
                            alert.showAndWait();
                            return;


                        }

                    }

                    t1.setStudents(sts);
                    t.getPlayers().add(t1);
                    Main.addTournment2(t);








                }
                else{

                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Team Error");
                    alert.setHeaderText("The given Team is there ");
                    alert.setContentText("To add a student to a team. Go to regitster");
                    alert.showAndWait();


                }









            }
            else{

                Alert alert = new Alert(Alert.AlertType.WARNING);

                alert.setTitle("Input Error");
                alert.setHeaderText("The given tournment does not exsist  ");
                alert.setContentText("Please give the name of exsisting tournment");
                alert.showAndWait();
                //n o tournment
            }


        }



    }

}
