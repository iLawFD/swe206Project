package sweo206proj;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public class Match implements Serializable {



    private String date;
    private int matchNumber, time;

    private boolean isPlayed;
    int[] score = new int[2];
    ArrayList<Participant> players = new ArrayList<>();

    Match(){


    }
    Match(ArrayList<Participant> players , String date){

        this.players = players;
        this.date =date;

       // this.matchNumber=matchNumber;
        score = null;


    }





    public Participant getWinner(){
        if(this.score[0] >= this.score[1] ){
            return this.getTeams().get(0);
        }
        else{
            return this.getTeams().get(1);
        }

    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getMatchNumber() {
        return matchNumber;
    }

    public void setMatchNumber(int matchNumber) {
        this.matchNumber = matchNumber;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public int[] getScore() {
        return score;
    }

    public void setScore(int[] score) {
        this.score = score;
    }

    public ArrayList<Participant> getTeams() {
        return players;
    }

    public void setTeams(ArrayList<Participant> players) {
        this.players = players;
    }

    @Override
    public String toString() {
        return "info to screen";
    }

    public boolean scoreIsEntered(){

        return score== null;
    }

    @Override
    public boolean equals(Object obj) {
        Match m = (Match) obj;

        return this.getTeams().equals(m.getTeams()) && Arrays.equals(this.score , m.getScore());
    }
}
