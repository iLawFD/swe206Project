package sweo206proj;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;









public class sMatchCont {





    @FXML
    HBox h ;

    @FXML
    TextField searchF;
    @FXML
    VBox tableV;
    static Pane holder = new Pane();







    @FXML
    protected void backAct(ActionEvent event) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("s2Admin.fxml"));


        Node node = (Node) event.getSource();

        Window win = ((Scene) node.getScene()) .getWindow();
        if (win != null) {
            Scene scene = win.getScene();
            if (scene != null) {
                javafx.stage.Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                FXMLLoader fxmlLoader2 = new FXMLLoader(Main.class.getResource("s2Student.fxml"));



                Scene scene2 = new Scene(fxmlLoader2.load(), 900, 600);
                stage.setScene(scene2);
            }
        }}


    @FXML
    public void initialize() throws IOException {

        //System.out.println(holder);


        // System.out.println(holder.getChildren());
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        String formattedDate = today.format(formatter);

        Main.addInfoToList(formattedDate,tableV.getChildren());

        // tableV.getChildren().add(new Button("s"));
        // System.out.println("Today's date: " + formattedDate);


    }

    @FXML
    protected void search() throws IOException {
        String date= searchF.getText();

        // System.out.println(date);
        boolean valid = true;

        if(!date.isEmpty()){
            if(Main.validateDate(date)){

                String date2 = date;
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
                // Parse the start date string into a LocalDate object
                LocalDate parsedStartDate = LocalDate.now();


                // Parse the end date string into a LocalDate object
                LocalDate parsedEndDate = LocalDate.parse(date2, formatter);

                System.out.println(parsedStartDate.isAfter(parsedEndDate));

                //tableV.getChildren().retainAll(new Button("w0fk"));
                System.out.println("Emt?");
                tableV.getChildren().removeAll(tableV.getChildren());

                Main.addInfoToList(date,tableV.getChildren());}

            else{

                Alert alert = new Alert(Alert.AlertType.WARNING);

                alert.setTitle("Input Error");
                alert.setHeaderText(" The given input is wrong ");
                alert.setContentText("try again");
                alert.showAndWait();
            }


        }
        else{
            Alert alert = new Alert(Alert.AlertType.WARNING);

            alert.setTitle("Empty input");
            alert.setHeaderText(" The filed is empty");
            alert.setContentText("Please try write before pressing subimt");
            alert.showAndWait();
        }





    }






}
