package sweo206proj;

import java.io.*;

public class AppendedObjectOutputStream extends ObjectOutputStream {

    public AppendedObjectOutputStream(OutputStream out) throws IOException {
        super(out);
    }

    @Override
    protected void writeStreamHeader() throws IOException {
        // Do nothing
    }
}

