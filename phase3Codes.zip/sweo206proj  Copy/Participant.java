package sweo206proj;

import java.io.Serializable;

public interface Participant extends  Serializable {
   //public String name = null;


     boolean equals(Object o);

     String getName();

}
