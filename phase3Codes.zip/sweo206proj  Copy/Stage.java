package sweo206proj;

public class Stage {

    int days;
    Participant loser;
    Participant winner;
    int stageNumber;
    Match match;


    boolean isPlayed(){

        return winner != null;

    }

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public Participant getLoser() {
        return loser;
    }

    public void setLoser(Participant loser) {
        this.loser = loser;
    }

    public Participant getWinner() {
        return winner;
    }

    public void setWinner(Participant winner) {
        this.winner = winner;
    }

    public int getStageNumber() {
        return stageNumber;
    }

    public void setStageNumber(int stageNumber) {
        this.stageNumber = stageNumber;
    }

    public Match getMatch() {
        return match;
    }

    public void setMatch(Match match) {
        this.match = match;
    }
}
