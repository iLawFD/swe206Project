package sweo206proj;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public class Team implements Participant, Serializable {

    private String name;
    private ArrayList<Student> students;
    private int teamNumber;


    Team(){

    }
    Team(ArrayList<Student> students, String name){
       this.students = students;
       this.name= name;


    }
    public void addStudent(Student student){


     // adds student to the arraylist

    }

    public void removeStudent(Student student){


        // remove student from the arraylist


    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<Student> getStudents() {

        //if(this.students == null)

        return students;
    }

    public void setStudents(ArrayList<Student> students) {
        this.students = students;
    }

    public int getTeamNumber() {
        return teamNumber;
    }

    public void setTeamNumber(int teamNumber) {
        this.teamNumber = teamNumber;
    }


   public boolean equals(Object o){
        Team t = (Team) o;

        return this.getName().equals(t.getName()) && students.equals(t.getStudents());

    }



}

class RoundRobinTeam extends  Team {

    RoundRobinTeam(ArrayList<Student> students, String name){
        super(students, name);

    }

    int losses ;
    int wins;
    int receivedGoals;
    int scoredGoals;
    int points;
    int draws;


    public boolean hasFinishedMatches(){



        return true;
    }

    public int getLosses() {
        return losses;
    }

    public int getWins() {
        return wins;
    }

    public int getReceivedGoals() {
        return receivedGoals;
    }

    public int getScoredGoals() {
        return scoredGoals;
    }

    public int getPoints() {
        return wins * 3 + losses * 0 + draws;
    }

    public int getDraws() {
        return draws ;

    }


    public void setLosses(int losses) {
        this.losses = losses;
    }

    public void setWins(int wins) {
        this.wins = wins;
    }

    public void setReceivedGoals(int receivedGoals) {
        this.receivedGoals = receivedGoals;
    }

    public void setScoredGoals(int scoredGoals) {
        this.scoredGoals = scoredGoals;
    }



    public void setDraws(int draws) {
        this.draws = draws;
    }
}



