package sweo206proj;

import java.io.Serializable;
import java.util.ArrayList;

public class StudentProfile implements Serializable {



    private   ArrayList<Integer> ranks ;

    private String userName;
    private Student student;
    private   ArrayList<Tournament> tournments ;

    public StudentProfile(Student student){
        this.student =student;
        this.tournments = new ArrayList<>();
        this.ranks = new ArrayList<>();
    }
    public boolean isReg(){

        // tournments != null or tourments does not contains finished tournment;


        return true;

    }

    public ArrayList<Tournament> getTournments() {
        return tournments;
    }


    public ArrayList<Integer> getRanks() {
        return ranks;
    }




    public Student getStudent() {
        return student;
    }



    public void setRanks(ArrayList<Integer> ranks) {
        this.ranks = ranks;
    }



    public void setTournments(ArrayList<Tournament> tournments) {
        this.tournments = tournments;
    }



}
