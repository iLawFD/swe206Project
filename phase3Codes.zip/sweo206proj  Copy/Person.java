package sweo206proj;

import java.io.Serializable;
import java.util.ArrayList;

public abstract class Person implements Serializable{

    private  String email, name, id;

    private Integer userName;


    private  Integer password;

    public void login(String userName, int password) {


    }
    public Tournament searchTournment(String name){


        Tournament tournment = new Tournament() ;

        return tournment;
    }
    public Tournament searchTournment(int code){


        Tournament tournment = new Tournament() ;

        return tournment;
    }
    public void viewProfile(String id){



    }

    public void viewTournment(String name){




    }

    public void viewTournment(int code){

    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getPassword() {
        return password;
    }

    public void setPassword(Integer password) {
        this.password = password;
    }


    public Integer getUserName() {
        return userName;
    }

    public void setUserName(Integer userName) {
        this.userName = userName;
    }
}
class Student extends Person implements Participant, Serializable {

    private Integer rank ;

    Student(String email, Integer userName, int password){

        this.setEmail(email);
        this.setUserName(userName);
        this.setPassword(password);


    }





    public void createProfile(Tournament tournment ){



    }

    public void register(Tournament tournment ){



    }


    public boolean equals(Student obj) {
        return this.getEmail().equals(obj.getEmail()) && this.getName().equals(obj.getName()) && this.getPassword() == obj.getPassword();

    }

    @Override
    public boolean equals(Object o) {
        Student s= (Student) o;

        return this.getEmail().equals(s.getEmail()) && s.getUserName() == ((Student) s).getUserName();

    }
}


class Admin extends Person{
    Admin(String email, String name, int password){

        this.setEmail(email);
        this.setName(name);
        this.setPassword(password);


    }



  public  void  addNewSportOrgame (SportGame SportGame){



    }

    public void generateTableOfMatches(String name){



    }

    public void generateTableOfMatches(int code){



    }

    public void modifyTeamMember(Tournament tournment , int number){




    }

    public void recordsScores(Tournament tournment , int score){

    }

    public void recordTournment(String name , boolean isIndv , SportGame sportGame , ArrayList<Team> teams){


      // create tournment outOf the parameters



    }

    public void registration(Student student, Tournament tournment){

      //adds student the players of the tournment

    }

    public void removeNewSportOrgame(SportGame sportGame){



    }


    public void setupStudentsProfiles(Student student){


    }

    public void stopRegistration(Tournament tournment){
      //tournment.isReg = false;


  }


  public void viewMatch (String date){


      //go over the list of matches with match.date = date
  }

    public void viewTable (Tournament tournment){

        //
    }


    public boolean equals(Object o) {
        Admin s= (Admin) o;

        return this.getEmail().equals(s.getEmail()) && s.getUserName() == ((Admin) s).getUserName();

    }
}














