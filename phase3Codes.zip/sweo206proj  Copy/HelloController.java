package sweo206proj;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Window;
import javafx.stage.Window;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import java.util.regex.Pattern;


public class HelloController {

    static double cSize = 1.2;
    @FXML
    private Label welcomeText;

    @FXML
    private Button createB;
    @FXML
    private Button logBt;

    @FXML
    private TextField usernameF;

    @FXML
    private TextField emailF;

    @FXML
    private TextField passwordF;
    @FXML


    private Label messageL;




    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }


    @FXML
    protected void onHCreateProfile() {
        createB.setScaleX(cSize +cSize * 20 /100);
        createB.setScaleY(cSize   + cSize* 20 /100);
    }


    @FXML
    protected void onHCreateProfileL() {
        createB.setScaleX(cSize  -cSize  * 20/100);
        createB.setScaleY(cSize  -cSize  * 20 /100);
    }


    @FXML
    protected void onLog() {
        logBt.setScaleX(cSize +cSize * 20 /100);
        logBt.setScaleY(cSize   + cSize* 20 /100);
    }


    @FXML
    protected void ongLogl() {
        logBt.setScaleX(cSize  -cSize  * 20/100);
        logBt.setScaleY(cSize  -cSize  * 20 /100);
    }



    @FXML
    protected void logAc(ActionEvent event) throws IOException {

       // System.out.println(event.getSource());
        String username = usernameF.getText();
        String email = emailF.getText();
        String passS = passwordF.getText();



        boolean nameIsdiig = false;



       // boolean isStudent= Main.validStudent(username);
        Admin isAdmin = Main.admintIsReg(username);

        boolean valid = true;
        boolean notEmpty = true;

        valid = Main.validInput(username , email , passS);
        notEmpty = Main.emptyInput(username , email , passS);



        if(notEmpty) {
            if (valid) {
                int password = Integer.valueOf(passS);
                 //   int userName = Integer.valueOf(username);
                  //  Student student = new Student(email, userName, password);










                String endpoint = "https://us-central1-swe206-221.cloudfunctions.net/app/UserSignIn";
                Scanner sc = new Scanner(System.in);
                System.out.println("Write your user name then your password:");
                String username1 =username  ;
                String password1 =  passS;
                sc.close();

                int resp = 0;
                String content =  "";
                try {
                    String urlStr = endpoint + "?username=" + username1 + "&password=" + password1;
                    URL url = new URL(urlStr);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                    connection.setRequestMethod("GET");

                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line;
                    StringBuilder response = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();

                    int responseCode = connection.getResponseCode();

                   // System.out.println("Response Code: " + responseCode);
                  //  System.out.println("Response Content: " + response.toString());
                    resp = responseCode;
                    content =  response.toString();

                    connection.disconnect();
                } catch (IOException e) {
                    Alert alert = new Alert(Alert.AlertType.WARNING);

                    alert.setTitle(" Error");
                    alert.setHeaderText("This app is for only admins and student of kfupm ");
                    alert.setContentText("If you are a student or admin make sure you entered your info correclty");
                    alert.showAndWait();
                }

















                    boolean validR = resp == 200;




                    if(validR){



                        if(content.toLowerCase().contains("admin")){

                            Node node = (Node) event.getSource();
                            Window win = ((Scene) node.getScene()).getWindow();
                            if (win != null) {
                                Scene scene = win.getScene();
                                if (scene != null) {
                                    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                                    FXMLLoader fxmlLoader2 = new FXMLLoader(Main.class.getResource("s2Admin.fxml"));
                                    Scene scene2 = new Scene(fxmlLoader2.load(), 900, 600);
                                    stage.setScene(scene2);
                                }



                            }



                        }
                        else{

                            Node node = (Node) event.getSource();
                            Window win = ((Scene) node.getScene()).getWindow();

                            if (win != null) {
                                Scene scene = win.getScene();
                                if (scene != null) {
                                    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                                    FXMLLoader fxmlLoader2 = new FXMLLoader(Main.class.getResource("s2Student.fxml"));


                                    Scene scene2 = new Scene(fxmlLoader2.load(), 900, 600);
                                    stage.setScene(scene2);
                                }
                            }


                        }










                    }







































            } else {

                Alert alert = new Alert(Alert.AlertType.WARNING);

                alert.setTitle("Input Error");
                alert.setHeaderText("One more or more of the given input is wrong! ");
                alert.setContentText("Please note that email must conatin @ and the password must consist of 8 digits or more");
                alert.showAndWait();

                //show error message: invalid input
            }
        }
        else{

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Input Error");
            alert.setHeaderText("One or more of the fields are empty! ");
            alert.setContentText("Please fill all of the information before pressing create account");
            alert.showAndWait();


            //show error message: fill information before pressing log in
        }






    }

    @FXML
    protected void createAct() throws IOException {

        String username = usernameF.getText();
        String email = emailF.getText();
        String passS = passwordF.getText();
        String text = "abc";


        boolean notEmpty = true;

        notEmpty = Main.emptyInput(username , email , passS);

        boolean valid = true;
        boolean isStudent= true;
        boolean isAdmin= true;




        valid = Main.validInput(username , email , passS);

        if(notEmpty) {
            System.out.println();
            if (valid) {


                int password = Integer.valueOf(passS);
                int userName = Integer.valueOf(username);
                if (isStudent) {

                    System.out.println("add");

                    Student student = new Student(email, userName, password);
                    StudentProfile result =  Main.addStudent(student);
                    System.out.println(result);

                   if(result != null){


                       System.out.println("Not added");
                       //show error message
                   }
                    else{
                    // show message that it has been created and user has to log in
                       System.out.println("created");
                       }



                } else if (isAdmin) {

                    // write info to text
                   // Admin result = Main.addAdmin( username ,  email,  password);






                } else {
                    // pop error message
                }

            } else {


                Alert alert = new Alert(Alert.AlertType.WARNING);

                alert.setTitle("Input Error");
                alert.setHeaderText("One more or more of the given input is wrong! ");
                alert.setContentText("Please note that email must conatin @ and the password must consist of 8 digits or more");
                alert.showAndWait();

            }
        }
        else{

            Alert alert = new Alert(Alert.AlertType.ERROR);

            alert.setTitle("Input Error");
            alert.setHeaderText("One or more of the fields are empty! ");
            alert.setContentText("Please fill all of the information before pressing create account");
            alert.showAndWait();

            //show error message: empty fields
        }






    }



}