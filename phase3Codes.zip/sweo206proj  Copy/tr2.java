package sweo206proj;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class tr2 {
    public static void main(String[] args) throws IOException {
        File file = new File("C:\\Users\\ggfor\\IdeaProjects\\sweo206Proj\\src\\main\\java\\com\\example\\sweo206proj\\tournments.dat");

        //String name , SportGame sportGame , boolean isIndv , String[] date)
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        String formattedDate = today.format(formatter1);
        Tournament tour = new Tournament("tt", new SportGame("a"), false, new String[]{"05/08/2023", "05/11/2023"});
        Tournament t2 = new Tournament("try", new SportGame("a"), false, new String[]{formattedDate, "02/09/2023"});
        Tournament t3 = new Tournament("tt", new SportGame("a"), true, new String[]{"1", "2"});
        Tournament t4 = new Tournament("tt", new SportGame("a"), false, new String[]{"1", "2"});


        //System.out.println(tour.equals(t4));
        Tournament t = Main.tournamentExsist("elm");
        System.out.println("num " +t.getMatches().get(0).getScore()[0]);


        ArrayList<Match> m = t.getMatches();
        ArrayList<Integer> scores = new ArrayList<>();
        scores.add(0,0);
        scores.add(1,0);
        scores.add(2,0);
        scores.add(3,0);
        TreeMap<String ,  ArrayList<Integer>> table = new TreeMap<>();

        for(int i = 0 ; i < m.size() ; i ++) {


            if (m.get(i).getScore() != null) {
                if (m.get(i).getScore()[0] > m.get(i).getScore()[1]) {

                    Participant p1 = m.get(i).getTeams().get(0);
                    Participant p2 = m.get(i).getTeams().get(1);
                    if (t.isIndv()) {


                    } else {
                        Team team1 = (Team) p1;
                        Team team2 = (Team) p2;

                        if (table.get(team1.getName()) == null) {

                            ArrayList<Integer> s = new ArrayList<>();
                            s.add(0, 0);
                            s.add(1, 0);
                            s.add(2, 0);
                            s.add(3, 0);

                            table.put(team1.getName(), s);

                        }

                        if (table.get(team2.getName()) == null) {
                            ArrayList<Integer> s = new ArrayList<>();
                            s.add(0, 0);
                            s.add(1, 0);
                            s.add(2, 0);

                            s.add(3, 0);
                            table.put(team2.getName(), s);
                        }
                        ArrayList<Integer> scor = table.get(team1.getName());
                        ArrayList<Integer> scor2 = table.get(team2.getName());


                        scor.set(0, scor.get(0) + 1);
                        scor.set(3, scor.get(3) + 3);
                        table.put(team1.getName(), scor);
                        scor2.set(1, scor2.get(1) + 1);
                        table.put(team2.getName(), scor2);
                    }


                } else {

                    Participant p1 = m.get(i).getTeams().get(0);
                    Participant p2 = m.get(i).getTeams().get(1);


                    if (t.isIndv()) {


                    } else {
                        Team team1 = (Team) p1;
                        Team team2 = (Team) p2;

                        if (table.get(team1.getName()) == null) {

                            ArrayList<Integer> s = new ArrayList<>();
                            s.add(0, 0);
                            s.add(1, 0);
                            s.add(2, 0);
                            s.add(3, 0);


                            table.put(team1.getName(), s);

                        }

                        if (table.get(team2.getName()) == null) {
                            ArrayList<Integer> s = new ArrayList<>();
                            s.add(0, 0);
                            s.add(1, 0);
                            s.add(2, 0);
                            s.add(3, 0);


                            table.put(team2.getName(), s);
                        }
                        ArrayList<Integer> scor = table.get(team1.getName());
                        ArrayList<Integer> scor2 = table.get(team2.getName());


                        scor.set(2, scor.get(2) + 1);
                        scor.set(3, scor.get(3) + 1);

                        table.put(team1.getName(), scor);

                        scor2.set(2, scor2.get(2) + 1);
                        scor2.set(3, scor2.get(3) + 1);
                        table.put(team2.getName(), scor2);


                    }

                }


            }
        }


        Set<String> keys = table.keySet();

        for (String key : keys) {
            System.out.println(table.get(key));
        }

      //  HashSet<String> set  =(HashSet) table.keySet();



   //     System.out.println(t.getDate()[1]);
       // System.out.println(t.getMatches().get(0).getDate());

        //System.out.println(t instanceof RoundRobin);
      //  System.out.println( t.getDate()[0].charAt(3));
        ArrayList<Participant> teams = t.getPlayers();
        ArrayList<Participant> teams2 = t.getPlayers();


        int count =0 ;



        Main.addTournment2(t);
        //System.out.println(s1.getPlayers().size());


       // System.out.println(((Team)tour.getPlayers().get(0)).getStudents().get(0).getUserName());
        //System.out.println(tour.getPlayers());
        //System.out.println("TOurn" + t2.isFinished());

        //System.out.println("players "+ t2.getPlayers());
       //t2.getPlayers().add(new Team(new ArrayList<>() , "team"));
        //Main.addTournment2(t2);


        //Tournament tr = Main.tournamentExsist("try");
        //Team m = (Team) tr.getPlayers().get(0);
        //System.out.println(m.getStudents().get(0).getUserName());
        //System.out.println(Main.studentIsReg(new Student("aaf",123,123)));
        //Main.addTournment2(t1);


        //System.out.println(Main.tournamentExsist("perf").getPlayers());
       // Tournament test =  Main.tournamentExsist(t1.getName());
        //System.out.println(test.getPlayers());

       //Main.addTournment(t1);
        //t1.getPlayers().add();



        //System.out.println(test.getPlayers());
       // t2.setPlayers(new ArrayList<>());
       // t2.getPlayers().add(new Student("fpkwg",9215,22424));
       // System.out.println(t2.equals(t1));
       // Main.addTournment2(t2);


        //Tournament test = Main.tournamentExsist(t1.getName());

       // System.out.println(test.getPlayers());
       // System.out.println(t1.equals(t2));
        //System.out.println(Main.tournamentExsist(t1.getName()));

       // System.out.println(Main.tournamentExsist(t2.getName()).getSportGame().getName());
       // System.out.println(Main.tournamentExsist(t1.getName()));
    }
}
