package sweo206proj;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.IOException;
import java.util.ArrayList;

public class s2ControlerAdmin {


    @FXML
    Button searchST;
    @FXML
    Button regStudentB;
    @FXML
    Button viewMatchB;
    @FXML
    Button viewTournmentB;

    @FXML
    Button b1;
    @FXML
    Button b2;
    @FXML
    Button b3;



    @FXML
    TextField f1;
    @FXML
    TextField f2;

    @FXML
    Button save1B;

    @FXML
    Button save2B;

    @FXML
    TextField searchF;

    @FXML
    Button submitB;

    @FXML
    Button teamsB;

    @FXML
    protected void viewTOur(ActionEvent event) throws IOException{


        Node node = (Node) event.getSource();

        Window win = ((Scene) node.getScene()) .getWindow();
        if (win != null) {
            Scene scene = win.getScene();
            if (scene != null) {
                javafx.stage.Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                FXMLLoader fxmlLoader2 = new FXMLLoader(Main.class.getResource("viewTOurnment.fxml"));


                Scene scene2 = new Scene(fxmlLoader2.load(), 900, 600);
                stage.setScene(scene2);
            }
        }





    }



    @FXML
    protected void searchSt() throws IOException {

        String name = searchF.getText();

        if(!name.isEmpty()){
            int userName = Integer.parseInt(name);
            Student st = new Student(name, userName, 123);
            StudentProfile student = Main.studentIsReg(st);
            if(student!= null){
                //System.out.println("entred");
                ArrayList<Tournament> tournaments = student.getTournments();
                ArrayList<Integer> ranks = student.getRanks();
                String info = "Tournment: ";


                for(int i =0 ; i < tournaments.size() ; i++){
                    if(tournaments.get(i) != null)
                        info = info +" "+ tournaments.get(i).getName() +" ,  ";

                }

                info = info + "\n Ranks: ";

                for(int i =0 ; i < ranks.size() ; i++){
                    if(ranks.get(i) != null)
                        info = info +" "+ tournaments.get(i).getName() +" ,  ";

                }

                Alert alert = new Alert(Alert.AlertType.INFORMATION);



                alert.setTitle("Student: ");
                alert.setHeaderText("The info of the student with userName" + userName);
                alert.setContentText( info);
                alert.showAndWait();






            }else{

                Alert alert = new Alert(Alert.AlertType.ERROR);



                alert.setTitle("Search student");
                alert.setHeaderText("There is not a student with the same email");
                alert.setContentText(" Please try to come up with a uniqure email when searching ");
                alert.showAndWait();


            }



        }
        else{

            Alert alert = new Alert(Alert.AlertType.ERROR);

            alert.setTitle("Empty input");
            alert.setHeaderText("The given filed is empty");
            alert.setContentText(" Please press write a email before pressing submit");
            alert.showAndWait();

        }




    }





    @FXML
    protected void addSport(){



        f1.setVisible(true);
        save1B.setVisible(true);






    }
    @FXML
    protected void removeSport(){
        f2.setVisible(true);

        save2B.setVisible(true);



    }

    @FXML
    protected void save1(){

        String name = f1.getText();
        if(!name.isEmpty()){

            if(Main.sportExsists(name) == null){

                Main.addSport(name);

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setWidth(alert.getWidth() + alert.getWidth() );

                alert.setHeight(alert.getHeight() + alert.getHeight() );

                alert.setTitle("Sport creation");
                alert.setHeaderText("The sport has been successfully added! ");
                alert.setContentText(" You can see it when creating a tournment in the record tournment section. You can also delete it throu the delete Sport button ");
                alert.showAndWait();



            }
            else{

                Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Sport creation");
                alert.setHeaderText("There already exsist a sport with the given name");
                alert.setContentText(" Please try to come up with a uniqure name for the sport ");
                alert.showAndWait();


            }


        }
        else{

            Alert alert = new Alert(Alert.AlertType.ERROR);

            alert.setTitle("Empty input");
            alert.setHeaderText("The given filed is empty");
            alert.setContentText(" Please press write a name before pressing save");
            alert.showAndWait();
        }





    }

    @FXML
    protected void save2(){
        String name = f2.getText();
        if(!name.isEmpty()){
            if(Main.sportExsists(name) !=  null){ // it is there

                Main.removeSport(name);
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setWidth(alert.getWidth() + alert.getWidth() );

                alert.setHeight(alert.getHeight() + alert.getHeight() );

                alert.setTitle("Sport removal");
                alert.setHeaderText("The sport has been successfully removed! ");
                alert.setContentText(" It will no longer appear in the record tournment section ");
                alert.showAndWait();


            }
            else{

                Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Sport removal");
                alert.setHeaderText("The given sport does not exists ");
                alert.setContentText(" Please remove an existing sport  ");
                alert.showAndWait();


            }



        }

        else{

            Alert alert = new Alert(Alert.AlertType.ERROR);

            alert.setTitle("Empty input");
            alert.setHeaderText("The given filed is empty");
            alert.setContentText(" Please press write a name before pressing save");
            alert.showAndWait();
        }




    }




    @FXML
    protected void recordTournment(ActionEvent event) throws IOException {


        Node node = (Node) event.getSource();

        Window win = ((Scene) node.getScene()) .getWindow();
        if (win != null) {
            Scene scene = win.getScene();
            if (scene != null) {
                javafx.stage.Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                FXMLLoader fxmlLoader2 = new FXMLLoader(Main.class.getResource("recordScene.fxml"));


                Scene scene2 = new Scene(fxmlLoader2.load(), 900, 600);
                stage.setScene(scene2);
            }
        }




    }

    @FXML
    protected void registerSt(ActionEvent event) throws IOException {
        Node node = (Node) event.getSource();

        Window win = ((Scene) node.getScene()) .getWindow();
        if (win != null) {
            Scene scene = win.getScene();
            if (scene != null) {
                javafx.stage.Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                FXMLLoader fxmlLoader2 = new FXMLLoader(Main.class.getResource("registerStudent.fxml"));


                Scene scene2 = new Scene(fxmlLoader2.load(), 900, 600);
                stage.setScene(scene2);
            }
        }




    }

    @FXML
    protected void viewMatch(ActionEvent event) throws IOException {

        Node node = (Node) event.getSource();

        Window win = ((Scene) node.getScene()) .getWindow();
        if (win != null) {
            Scene scene = win.getScene();
            if (scene != null) {
                javafx.stage.Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                FXMLLoader fxmlLoader2 = new FXMLLoader(Main.class.getResource("viewMatches.fxml"));


                Scene scene2 = new Scene(fxmlLoader2.load(), 900, 600);
                stage.setScene(scene2);
            }
        }




    }



    @FXML
    protected void teams(ActionEvent event) throws IOException{

        System.out.println("Ent?");
        teamsB.setDisable(false);
        Node node = (Node) event.getSource();
        Window win = ((Scene) node.getScene()) .getWindow();
        if (win != null) {
            Scene scene = win.getScene();
            if (scene != null) {
                javafx.stage.Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                FXMLLoader fxmlLoader2 = new FXMLLoader(Main.class.getResource("teams.fxml"));


                Scene scene2 = new Scene(fxmlLoader2.load(), 900, 600);
                stage.setScene(scene2);
            }
        }



    }


    @FXML
    protected void viewTournment(){




    }

    @FXML
    protected void search(){




    }








}
