package sweo206proj;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;

public class Main extends Application {


    @Override
    public void start(Stage stage) throws IOException {
       //FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("s2Admin.fxml"));
       FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("s2Admin.fxml"));

     // FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("hello-view.fxml"));

//   FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("s2Student.fxml"));
        //  FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("roundScene.fxml"));

        //Label myLabel = (Label) root.lookup("#thing");
        //myLabel.setText("s");

        // Object[] objectsToWrite = { "Hello", 123, 3.14, true };


        // Open a binary file for writing


        Scene scene = new Scene(fxmlLoader.load(), 900, 600);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();


    }

    public static void main(String[] args) {
        launch();
    }

    public static boolean validInput(String username, String email, String password) {



        // Check if the email is in a valid format
        if (!email.matches("\\b[\\w.%-]+@[-.\\w]+\\.[A-Za-z]{2,4}\\b")) {

            return false;
        }
        try {
            Integer.valueOf(password);

        } catch (Exception e) {

            return false;
        }


        if (String.valueOf(password).length() != 4) {
            return false;
        }


        return true;
    }


    public static boolean emptyInput(String username, String email, String passS) {

        // Check if any of the input parameters are null or empty
        if (username == null || username.isEmpty() ||
                email == null || email.isEmpty() || passS == null || passS.isEmpty() ) {
            return false;
        }


        else{return true;
        }



    }

    public static boolean emptyInput(String name , String isIndv,String type, String sportName, String date1, String dat2){




        return true;


    }

    public static boolean validInput(String isIndv, String type, String date1 ,String date2) {

        try {
            // Define the date format used in the input strings
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

            // Parse the start date string into a LocalDate object
            LocalDate parsedStartDate = LocalDate.parse(date1, formatter);

            // Parse the end date string into a LocalDate object
            LocalDate parsedEndDate = LocalDate.parse(date2, formatter);

            // Check if the start date is before the end date
            if (parsedStartDate.isAfter(parsedEndDate)) {
                return false;
            }

                /*/ Check if the start date and end date are within the same year
                if (parsedStartDate.getYear() != parsedEndDate.getYear()) {
                    return false;
                }/*/

            // Check if the start date is within the valid range of American calendar
            if (parsedStartDate.getYear() < 2023 || parsedStartDate.getYear() > 2024) {

                return false;
            }

            // Check if the end date is within the valid range of American calendar
            if (parsedEndDate.getYear() < 2023 || parsedEndDate.getYear() > 2023) {

                return false;
            }

            // All checks passed, return true
            return true;
        } catch (DateTimeParseException e) {
            System.out.println("ex2?");
            // Invalid date format, return false
            return false;
        }


    }

    public static SportGame sportExsists(String name){

       // SportGame returnValue = new SportGame(name);


        File file = new File("C:\\Users\\ggfor\\IdeaProjects\\sweo206Proj\\src\\main\\java\\com\\example\\sweo206proj\\sports.dat");

        try (ObjectInputStream oos = new ObjectInputStream(new FileInputStream(file))) {

            while (true) {

                System.out.println("je");
                SportGame game = (SportGame)  oos.readObject();
               ;
                if(game.getName().toLowerCase().equals(name.toLowerCase())){
                    return game;
                }

            }
        } catch (ClassNotFoundException | IOException e) {
            return null;
        }



        // return returnValue;
    }



    public static SportGame addSport(String name){


        SportGame value = new SportGame(name);
        File file = new File("C:\\Users\\ggfor\\IdeaProjects\\sweo206Proj\\src\\main\\java\\com\\example\\sweo206proj\\sports.dat");


        if(file.exists()) {
            if (Main.sportExsists(name) == null) {
                ArrayList<SportGame> objs = new ArrayList<>();
                try (ObjectInputStream oos = new ObjectInputStream(new FileInputStream(file))) {
                    while (true) {

                        objs.add((SportGame) oos.readObject());

                    }


                } catch (EOFException e) {

                    try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
                        for (int i = 0; i < objs.size(); i++) {
                            oos.writeObject(objs.get(i));
                        }

                        oos.writeObject(value);
                        return null;

                    }
                    catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }


                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            } else {

                return null;

            }
        }

        else{
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {

                oos.writeObject(value);
                return value;

            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        }

    public static void removeSport(String name){

        SportGame value = new SportGame(name);
        File file = new File("C:\\Users\\ggfor\\IdeaProjects\\sweo206Proj\\src\\main\\java\\com\\example\\sweo206proj\\sports.dat");


        if(file.exists()) {
                ArrayList<SportGame> objs = new ArrayList<>();
                try (ObjectInputStream oos = new ObjectInputStream(new FileInputStream(file))) {
                    while (true) {

                        SportGame sport= (SportGame) oos.readObject();
                        if(!sport.getName().equals(name))
                            objs.add(sport);

                    }


                } catch (EOFException e) {

                    try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
                        for (int i = 0; i < objs.size(); i++) {
                            oos.writeObject(objs.get(i));

                        }

                       // oos.writeObject(value);
                       // return null;

                    }
                    catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }


                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

        }



    }











    public static Admin admintIsReg(String name){

        File file = new File("C:\\Users\\ggfor\\IdeaProjects\\sweo206Proj\\src\\main\\java\\com\\example\\sweo206proj\\admin.dat");


        if(file.exists()){
            try (ObjectInputStream oos = new ObjectInputStream(new FileInputStream(file))) {

                while (true) {

                    System.out.println("je");
                    Admin admin = (Admin)  oos.readObject();
                    System.out.println(admin.getName());
                    if(admin.getName().equals(name)){

                        return admin;
                    }


                }
            } catch (EOFException | ClassNotFoundException | FileNotFoundException e) {
                return null;
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        else
        {
            return null;
        }


    }


    public static StudentProfile addProfile(StudentProfile profile) throws IOException {
        //StudentProfile profile = new StudentProfile(student);

        File file = new File("C:\\Users\\ggfor\\IdeaProjects\\sweo206Proj\\src\\main\\java\\com\\example\\sweo206proj\\profiles.dat");



        StudentProfile result = null;
        if (file.exists()) {
            ArrayList<StudentProfile> objs = new ArrayList<>();
            try (ObjectInputStream oos = new ObjectInputStream(new FileInputStream(file))) {

                    while (true) {

                        StudentProfile p = (StudentProfile) oos.readObject();
                      //  System.out.printf(" 1 "+p.getStudent().getUserName());
                       // System.out.printf(" 2 "+profile.getStudent().getUserName());
                        if(!(p.getStudent().getUserName().equals(profile.getStudent().getUserName())))
                            objs.add(p);

                        else{
                            System.out.println("??");
                            objs.add(profile);
                        }

                    }



                }
                catch (EOFException e) {


                    try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
                        for (int i = 0; i < objs.size(); i++) {
                            // System.out.println(objs.get(i).getName());
                            oos.writeObject(objs.get(i));
                        }


                    }
                }

                catch (ClassNotFoundException ex) {
                    throw new RuntimeException(ex);
                }


                return result;




        } else {
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {

                oos.writeObject(profile);

            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        return profile;


    }


    // System.out.println("swsf");
    //return tournamnet;
    //

    public static StudentProfile addStudent(Student student) throws IOException {
        StudentProfile profile = new StudentProfile(student);

        File file = new File("C:\\Users\\ggfor\\IdeaProjects\\sweo206Proj\\src\\main\\java\\com\\example\\sweo206proj\\profiles.dat");



        StudentProfile result = null;
            if (file.exists()) {


                 result = Main.studentIsReg(student);
                if(result == null ) {

                    ArrayList<StudentProfile> objs = new ArrayList<>();

                    try (ObjectInputStream oos = new ObjectInputStream(new FileInputStream(file))) {

                        while (true) {

                            objs.add((StudentProfile) oos.readObject());

                        }


                    } catch (EOFException e) {

                        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
                            for (int i = 0; i < objs.size(); i++) {
                                oos.writeObject(objs.get(i));
                            }
                            oos.writeObject(profile);
                            return null;
                            //System.out.println("ah");
                        }


                        //System.out.println("ed");

                    }
                    catch (ClassNotFoundException e) {

                        throw new RuntimeException(e);

                    }
                }
                else{
                    return result;
                }



            } else {
                try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {

                    oos.writeObject(profile);

                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }

return profile;


    }

    public static StudentProfile studentIsReg(Student student) throws IOException {


        // read the binary file and make sure one profile has attribute student = student


        File file = new File("C:\\Users\\ggfor\\IdeaProjects\\sweo206Proj\\src\\main\\java\\com\\example\\sweo206proj\\profiles.dat");

        if(file.exists()){
        try (ObjectInputStream oos = new ObjectInputStream(new FileInputStream(file))) {

            while (true) {

                System.out.println("je");
                StudentProfile profile = (StudentProfile)  oos.readObject();
                System.out.println(profile.getStudent().getEmail());
                if(student.getUserName().equals(profile.getStudent().getUserName())){

                    return profile;
                }


            }
        } catch (EOFException | ClassNotFoundException e) {
            return null;
        }}
        else
        {
            return null;
        }








    }

    public static Tournament tournamentExsist(String name) throws IOException {

        Tournament dummy = null;

        File file = new File("C:\\Users\\ggfor\\IdeaProjects\\sweo206Proj\\src\\main\\java\\com\\example\\sweo206proj\\bro.dat");
        // go over the binary and check if tournment.name == name
        if (file.exists()) {

            ArrayList<Tournament> objs = new ArrayList<>();
            try (ObjectInputStream oos = new ObjectInputStream(new FileInputStream(file))) {

                while (true) {

                    Tournament tournament = (Tournament) oos.readObject();
                    System.out.println(tournament.getName());

                    if(tournament.getName().equals(name)){
                        return tournament;
                    }

                }


            }
            catch (EOFException e) {

                return null;


                //System.out.println("ed");

            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }

        }
        else{

            return null;
        }





    }

    public static boolean validateDate(String date1){
        try {
            // Define the date format used in the input strings
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

            // Parse the start date string into a LocalDate object
            LocalDate parsedStartDate = LocalDate.parse(date1, formatter);

            // Check if the start date is within the valid range of American calendar
            if (parsedStartDate.getYear() < 2023 || parsedStartDate.getYear() > 2024) {
                return false;
            }

            // All checks passed, return true
            return true;
        } catch (DateTimeParseException e) {
            // Invalid date format, return false
            return false;
        }
    }
    public static void addInfoToList(String date, ObservableList<Node> info) throws IOException {




        Tournament dummy = null;

        File file = new File("C:\\Users\\ggfor\\IdeaProjects\\sweo206Proj\\src\\main\\java\\com\\example\\sweo206proj\\bro.dat");


        // go over the binary and check if tournment.name == name



        if (file.exists()) {
            //System.out.println("How");
            ArrayList<Tournament> objs = new ArrayList<>();
            try (ObjectInputStream oos = new ObjectInputStream(new FileInputStream(file))) {

               // System.out.println("j?");
                while (true) {

                    Tournament tournament = (Tournament) oos.readObject();
                    ArrayList<Match> matches = tournament.getMatches();


                    String mInfo = " ";
                    System.out.println(tournament.getName());

                    if(matches == null)
                        return ;

                    int count = 0;
                    for(int i =0 ; i<matches.size() ; i ++){

                        //System.out.println("hm");
                        //System.out.println(matches.get(i).getDate());
                        System.out.println(matches.get(i));

                        if(matches.get(i).getDate().equals(date)){
                            viewMatchesControler.t = tournament;

                            Match m = matches.get(i);
                            if(m.getScore() != null)
                             mInfo = "Date "  + m.getDate() +" Players: "+ m.getTeams().get(0).getName()
                                     + " VS " +m.getTeams().get(1).getName() + " Scores: "+m.getScore()[0] + " TO "+ m.getScore()[1] + " Tour: " + tournament.getName();
                            else{
                                mInfo = "Date "  + m.getDate() +" Players: "+ m.getTeams().get(0).getName() + " VS " +m.getTeams().get(1).getName()
                                        + "No Scores!"+ " Tour: " + tournament.getName() ;
                            }
                            Button b1 = new Button(mInfo);
                            //System.out.println(matches.get(i).getScore()==null);
                           if(matches.get(i).getScore() == null ){
                               try {
                                   // Define the date format used in the input strings
                                   DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

                                   // Parse the start date string into a LocalDate object
                                   LocalDate parsedStartDate = LocalDate.parse(matches.get(i).getDate(), formatter);

                                   LocalDate today = LocalDate.now();
                                   DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("MM/dd/yyyy");
                                   String formattedDate = today.format(formatter1);

                                   LocalDate parsedEndDate = LocalDate.parse(formattedDate, formatter);

                                   // Check if the start date is before the end date
                                   if (parsedStartDate.isBefore(parsedEndDate)) {
                                       b1.setStyle("-fx-background-color: red;");

                                      //
                                   }
                               }catch (Exception e){

                               }


                               //b1.setId("my-button");


                              // System.out.println("d");
                           }


                            info.add(b1);
                            viewMatchesControler.makeAct(b1,matches.get(i) , tournament, count );
                            count ++;

                        }

                    }


                }


            }
            catch (EOFException e) {



                //System.out.println("ed");

            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }

        }







    }

    public static StudentProfile addStudent1(Student student) throws IOException {
        StudentProfile profile = new StudentProfile(student);

        File file = new File("C:\\Users\\ggfor\\IdeaProjects\\sweo206Proj\\src\\main\\java\\com\\example\\sweo206proj\\profiles.dat");


        StudentProfile result = null;
        if (file.exists()) {


            result = Main.studentIsReg(student);
            if (result == null) {

                ArrayList<StudentProfile> objs = new ArrayList<>();
                try (ObjectInputStream oos = new ObjectInputStream(new FileInputStream(file))) {

                    while (true) {

                        objs.add((StudentProfile) oos.readObject());

                    }


                } catch (EOFException e) {

                    try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
                        for (int i = 0; i < objs.size(); i++) {
                            oos.writeObject(objs.get(i));
                        }
                        oos.writeObject(profile);
                        return null;

                    }


                    //System.out.println("ed");

                } catch (ClassNotFoundException e) {

                    throw new RuntimeException(e);

                }
            } else {
                return result;
            }


        } else {
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {

                oos.writeObject(profile);

            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return null;
    }

    public static Tournament addTournment2(Tournament tournamnet) throws IOException {

        File file = new File("C:\\Users\\ggfor\\IdeaProjects\\sweo206Proj\\src\\main\\java\\com\\example\\sweo206proj\\bro.dat");

        if (file.exists()) {

            Tournament result = Main.tournamentExsist(tournamnet.getName());

            //System.out.println(result.getName());
            ArrayList<Tournament> objs = new ArrayList<>();
            if (result == null) {


                try (ObjectInputStream oos = new ObjectInputStream(new FileInputStream(file))) {

                    System.out.println(objs.size());
                    while (true) {


                        objs.add((Tournament) oos.readObject());
                        //System.out.println("Number of");

                    }





                }
                catch (EOFException e) {


                    try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
                        for (int i = 0; i < objs.size(); i++) {
                           // System.out.println(objs.get(i).getName());
                            oos.writeObject(objs.get(i));
                        }
                        oos.writeObject(tournamnet);
                        return null;

                    }
                }

                catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }

            } else {
                System.out.println("e1?");

                if(tournamnet.equals(result))
                    return tournamnet;

                try (ObjectInputStream oos = new ObjectInputStream(new FileInputStream(file))) {

                    System.out.println(objs.size());
                    while (true) {
                        Tournament read = (Tournament) oos.readObject();

                        if(!read.getName().equals(tournamnet.getName()))
                            objs.add(read);
                        else{
                            objs.add(tournamnet);
                        }
                    }





                }
                catch (EOFException e) {


                    try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
                        for (int i = 0; i < objs.size(); i++) {
                            // System.out.println(objs.get(i).getName());
                            oos.writeObject(objs.get(i));
                        }
                       // oos.writeObject(tournamnet);
                       // return null;

                    }
                }


                catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }


                // System.out.println("swsf");
                //return tournamnet;
            }


        }

        else{

                try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {

                    oos.writeObject(tournamnet);

                    oos.close();

                } catch (IOException e) {
                    throw new RuntimeException(e);
                }


            }


        return null;

    }


    public static Tournament addTournmentDONOT(Tournament tournamnet) throws IOException {

        File file = new File("C:\\Users\\ggfor\\IdeaProjects\\sweo206Proj\\src\\main\\java\\com\\example\\sweo206proj\\bro.dat");


        Tournament value = null;
        if(file.exists()) {
            Tournament result = Main.tournamentExsist(tournamnet.getName());
            //System.out.println(result);
            ArrayList<Tournament> objs = new ArrayList<>();
            if (result == null) {


                try (ObjectInputStream oos = new ObjectInputStream(new FileInputStream(file))) {
                    System.out.println("Ent?");
                    while (true) {
                        //System.out.println("?");
                        Tournament t =(Tournament) oos.readObject();
                        objs.add(t);

                    }




                } catch (EOFException e) {



                    try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
                       // System.out.println("e1");
                        System.out.println(objs.size());
                        for (int i = 0; i < objs.size(); i++) {

                            System.out.println(objs.get(i));

                            oos.writeObject(objs.get(i));
                            //System.out.println(objs.get(i).getName());
                        }


                        oos.writeObject(tournamnet);
                        oos.close();
                        return null;

                    }


                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }

               catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            else{

               // if(tournamnet.equals(result))



                try (ObjectInputStream oos = new ObjectInputStream(new FileInputStream(file))) {
                    System.out.println("Ent?");
                    while (true) {
                        //System.out.println("?");
                        Tournament t =(Tournament) oos.readObject();
                        objs.add(t);
                        return null;

                    }





                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }


            }

        }

        else {
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {

                oos.writeObject(tournamnet);
                oos.close();
                return tournamnet;


            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }



    }


    public static void addSportsToList(ObservableList list){

        File file = new File("C:\\Users\\ggfor\\IdeaProjects\\sweo206Proj\\src\\main\\java\\com\\example\\sweo206proj\\sports.dat");


        if(file.exists()) {

            ArrayList<SportGame> objs = new ArrayList<>();
            try (ObjectInputStream oos = new ObjectInputStream(new FileInputStream(file))) {
                while (true) {


                    SportGame game  = (SportGame) oos.readObject();
                    //System.out.println(game.getClass());
                    objs.add(game);

                }


            } catch (EOFException e) {

                    for (int i = 0; i < objs.size(); i++) {
                       // System.out.println(objs.get(i).getName());
                        list.add(objs.get(i).getName());
                }
                return ;


            }
            catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }


            // read sportgame names binary file to the list


        }





    }

    public static Student studentIsInFIle(int userName){

        return new Student("fwoswf" , 131,123);

    }

    public static StudentProfile searchByUserName(int userName){



        File file = new File("C:\\Users\\ggfor\\IdeaProjects\\sweo206Proj\\src\\main\\java\\com\\example\\sweo206proj\\profiles.dat");

        if(file.exists()){
            try (ObjectInputStream oos = new ObjectInputStream(new FileInputStream(file))) {

                while (true) {

                    //System.out.println("je");
                    StudentProfile profile = (StudentProfile)  oos.readObject();
                    //System.out.println(profile.getStudent().getEmail());
                    if(userName ==(profile.getStudent().getUserName())){

                        return profile;
                    }


                }
            } catch (EOFException | ClassNotFoundException | FileNotFoundException e) {
                return null;
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        else
        {
            return null;
        }

       // return new StudentProfile(new Student("fwoswf" , 131,123));

    }



    public static boolean isNumber(String text, String text2){

        return true;

    }


}