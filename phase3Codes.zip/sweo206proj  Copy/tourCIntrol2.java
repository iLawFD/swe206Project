package sweo206proj;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class tourCIntrol2 {





    @FXML
    VBox v1;
    @FXML
    VBox v2;
    @FXML
    VBox v3;


    static Tournament t = null;


    @FXML
    public void initialize() throws IOException {
        File file = new File("C:\\Users\\ggfor\\IdeaProjects\\sweo206Proj\\src\\main\\java\\com\\example\\sweo206proj\\bro.dat");


        if (file.exists()) {

            try (ObjectInputStream oos = new ObjectInputStream(new FileInputStream(file))) {

                while (true) {

                    Tournament tournament = (Tournament) oos.readObject();


                    LocalDate today = LocalDate.now();
                    DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("MM/dd/yyyy");
                    String formattedDate = today.format(formatter1);

                    //  LocalDate tourDate = LocalDate.parse(tournament.getDate()[0],formatter1);

                    String r = tournament.getDate()[1];
                    LocalDate tourDate2 = LocalDate.parse(r,formatter1);



                    if(tournament.getDate()[0].equals(formattedDate)  ){
                        Text b1 = new Text(tournament.toString());
                        v2.getChildren().add(b1);


                    }
                    else if (tourDate2.isBefore(today)){
                        v1.getChildren().add(new Text(tournament.toString()));


                    }else{


                        Text b1 = new Text(tournament.toString());
                        v3.getChildren().add(b1);






                    }



                }


            }
            catch (EOFException e) {

                return;


                //System.out.println("ed");

            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }

        }



    }


    @FXML
    protected void backAct(ActionEvent event) throws IOException {

      //  FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("s2Admin.fxml"));


        Node node = (Node) event.getSource();

        Window win = ((Scene) node.getScene()) .getWindow();
        if (win != null) {
            Scene scene = win.getScene();
            if (scene != null) {
                javafx.stage.Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                FXMLLoader fxmlLoader2 = new FXMLLoader(Main.class.getResource("s2Student.fxml"));



                Scene scene2 = new Scene(fxmlLoader2.load(), 900, 600);
                stage.setScene(scene2);
            }
        }}



}
//}
