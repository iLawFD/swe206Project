package sweo206proj;

import java.io.Serializable;
import java.util.ArrayList;

public class SportGame implements Serializable {



    static transient ArrayList<SportGame> sportGames = new ArrayList<>();

    private String name;

    SportGame(String name){
        this.name = name;
    }

    public boolean validSportGame(String name){




        return true;


    }

    public String getName() {
        return name;
    }


    public boolean equals(SportGame obj) {
        return this.name.equals(obj.getName());
    }
}
