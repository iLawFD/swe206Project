package sweo206proj;

import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmailSender {
    public static void main(String[] args) {
        // SMTP server details
        String smtpServer = "smtp.office365.com";
        int smtpPort = 587;

        // Sender and recipient email addresses
        String senderEmail = "tournmenteofficial@outlook.com";
        String recipientEmail = "ggforever111@gmail.com";

        // Sender's credentials
        String username = "tournmenteofficial@outlook.com";
        String password = "1234--QWer";

        // Email content
        String subject = "Tourrnmente reg ";
        String body = "You have been added to the tournemnete!.";

        // SMTP server properties
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", smtpServer);
        props.put("mail.smtp.port", smtpPort);

        // Create an authenticator with the sender's credentials
        Authenticator authenticator = new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        };

        // Create a session with the SMTP server
        Session session = Session.getInstance(props, authenticator);

        try {
            // Create a new email message
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(senderEmail));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
            message.setSubject(subject);
            message.setText(body);

            // Send the email
            Transport.send(message);

            System.out.println("Email sent successfully!");
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
}