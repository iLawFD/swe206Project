package sweo206proj;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;

public  class Tournament implements Serializable {
    private static final long serialVersionUID = 365454742301711486L;
   private int capacity;
   private int code;
    private  String[] date;
    private String name;
    private boolean isIndv ;
    private ArrayList<Match> matches;

    boolean reg = true;
    private ArrayList<Participant> players; //could be of team objects or student objects

    private SportGame sportGame;
    private Team winner;


    Tournament(){



    }


    Tournament(String name , SportGame sportGame , boolean isIndv , String[] date){
        this.name =name;
        this.sportGame = sportGame ;
        this.isIndv = isIndv;
        this.date =date;
        this.players= new ArrayList<>();

        this.matches = new ArrayList<>();


    }



    public void addMatch(Match match){

        //adds to list
        this.getMatches().add(match);


    }

    public void addPlayer(Participant player){

        //adds to list

        players.add(player);

    }

    public ArrayList<Participant> getPlayers() {
        return players;
    }

    public Team checkTeam(String name){

        if(players == null)
            return null;

      for(int i =0 ; i <players.size() ; i++){
         // Team t =
          if  (((Team)players.get(i)).getName().equals(name)){
              return (Team)players.get(i) ;
          }

      }
      return null;
    }

    public void generateTable(String timeDiff){

        //check match.time - match2.time = timeDiff

    }
    public  boolean isFinished(){


       String date2 = date[1];
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        // Parse the start date string into a LocalDate object
        LocalDate parsedStartDate = LocalDate.now();


        // Parse the end date string into a LocalDate object
        LocalDate parsedEndDate = LocalDate.parse(date2, formatter);

      // System.out.println(parsedStartDate.isAfter(parsedEndDate));

        if(parsedStartDate.isBefore(parsedEndDate)){
            return false;

        }


        // go over the list of matches and check if all are true


        return true;

    }


    public boolean isInTournment( Participant player){

        // go over the list of teams and check if team exsist

        return players.contains(player);


    }
    public boolean isReg(){


        return reg;
    }

    public void removePlayer(Participant player){

        players.remove(player);
    }




    public static  boolean validName(String name){

        String tournamentName = name;

        // Check if the tournament name is null or empty
        if (tournamentName == null || tournamentName.isEmpty()) {
            return false;
        }

        // Check if the tournament name contains any invalid characters
        for (int i = 0; i < tournamentName.length(); i++) {
            char c = tournamentName.charAt(i);
            if (!Character.isLetterOrDigit(c) && c != ' ') {
                return false;
            }
        }
        char c = tournamentName.charAt(0);
        if(Character.isDigit(c)){
            return false;
        }
        if(tournamentName.length()>10){
            return false;
        }

        // All checks passed, tournament name is valid
        return true;


    }

    public static  boolean validCode(int code){

        return true;

    }


    public boolean periodIsVlaid(Match match){

        //checks if the match.date is in tournment.date
        return true;
    }

    public void setMatches(ArrayList<Match> matches) {
        this.matches = matches;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getCode() {
        return code;
    }
    public Team checkTeamName(String name){
        if(isIndv)
            return null;

        ArrayList<Participant> players2 = players;

      //  ArrayList<Team> p = (ArrayList<Team>) players;

        if(players == null)
            return null;

        for(int i =0 ; i <players.size() ; i++){

            Participant p = players.get(i);
            Team t= (Team)p;
            if(t.getName().equals(name)){
                return t;
            }
        }
        return null;



    }

    public Team addToTeam(String name, Student par){
        if(isIndv)
            return null;

        ArrayList<Participant> players2 = players;

        //  ArrayList<Team> p = (ArrayList<Team>) players;

        if(players == null)
            return null;

        for(int i =0 ; i <players.size() ; i++){

            Participant p = players.get(i);
            Team t= (Team)p;
            if(t.getName().equals(name)){
                t.getStudents().add(par);
                return t;

            }
        }
        return null;



    }





    public String[] getDate() {
        return date;
    }

    public void setDate(String[] date) {

        if(this.isFinished() == false)
                this.date = date;


    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isIndv() {
        return isIndv;
    }





    public ArrayList<Match> getMatches() {
        return matches;
    }



    public void setReg(boolean reg) {
        this.reg = reg;
    }

    public ArrayList<Participant> getTeams() {
        return players;
    }


    public void setPlayers(ArrayList<Participant> players) {
        this.players = players;
    }

    public SportGame getSportGame() {
        return sportGame;
    }

    public void setSportGame(SportGame sportGame) {
        this.sportGame = sportGame;
    }

    public Team getWinner() {
        return winner;
    }

    public void setWinner(Team winner) {
        this.winner = winner;
    }

    @Override
    public String toString() {
        return "name : " + this.getName() + "Start: " + this.getDate()[0] + "\n Ends: " + this.getDate()[1];
    }

    @Override
  public boolean equals(Object obj) {



        Tournament o = (Tournament)  obj;

        if(o.getPlayers() == null && this.getPlayers() != null)
            return false;

        if(this.getPlayers() == null && o.getPlayers() != null)
            return false;



        if(this.getPlayers() ==  null && o.getPlayers() == null){
            return this.getName().equals( o.getName()) && Arrays.equals(this.getDate(), o.getDate()) && this.isIndv() == o.isIndv() && this.getMatches().equals(o.getMatches())
                    &&this.getSportGame().equals(o.getSportGame())  ;

        }else{
        return this.getName().equals( o.getName()) && Arrays.equals(this.getDate(), o.getDate()) && this.isIndv() == o.isIndv() &&this.getMatches().equals(o.getMatches())
                &&this.getSportGame().equals(o.getSportGame()) && this.getPlayers().equals(o.getPlayers()) ;
        }
    }
}

class Elimination extends Tournament {





    ArrayList<Stage> stages ;

    Elimination(String name , SportGame sportGame , boolean isIndv , String[] date){
        super( name ,  sportGame ,  isIndv ,  date);
    }

    public void eliminate(Team team){

        // removes a team from the tournment
    }
    public void generateStage(Match matchf){

        // removes a team from the tournment
    }

    public void moveToNextStage(Stage stage, Participant participant){


    }

    public void viewStageResult(int stageNumber, Tournament tournment){
        //get the stage from stage.get(stageNumber)

    }




}

class RoundRobin extends Tournament {


    ArrayList<Round> rounds ;// rounds
    ArrayList<RoundRobinTeam> robinTeams ; // will be created out of the players list that it already inheriets

    RoundRobin(String name , SportGame sportGame , boolean isIndv , String[] date){
        super( name ,  sportGame ,  isIndv ,  date);
    }

    public void generateRounds(){

    }

    public void generateTable(){

    }


    public Match getDircetMatch( Team team1 , Team team2){


        return new Match();
    }






}


