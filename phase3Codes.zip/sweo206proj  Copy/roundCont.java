package sweo206proj;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

import java.io.IOException;
import java.util.*;

public class roundCont {



    @FXML
    Pane p;

    @FXML
    HBox h;

    @FXML
    HBox h2;

    static  Tournament t = null;
    static int days = 1;
    static  String  winn = "There is no current winner" ;


    public void initialize() throws IOException {
       // ageColumn.setCellFactory(new PropertyValueFactory<>("s"));


        h.setSpacing(15);
        h2.setSpacing(15);




        if (t instanceof RoundRobin) {


            int columns = t.getPlayers().size() -1;
            int rows =( t.getPlayers().size() * (t.getPlayers().size() -1)/2)/ (columns );

            //view

            Map<Participant, ArrayList<String>> map = new HashMap<>();

            ArrayList<Participant> teams = t.getPlayers();
            ArrayList<Participant> teams2 = t.getPlayers();


            ArrayList<String> matches = new ArrayList<>();

            boolean addAble = t.getMatches().size() == 0;
            int count = 0;
            for(int i = 0 ; i < teams.size() ; i ++){


                for(int j =(i+1) ;j < (teams.size()) ; j ++){


                        String name ="";
                        String name2 = "";
                        if(teams.get(i) instanceof Team){
                            name = ((Team)teams.get(i)).getName();
                            name2 = ((Team)teams2.get(j)).getName();

                        }
                        else{
                            name = String.valueOf(((Student)teams.get(i)).getUserName());
                            name2 = String.valueOf(((Student)teams2.get(j)).getUserName());
                        }

                    System.out.println(name + " Vs " + name2 );
                    ArrayList<Participant> playe = new ArrayList<>();
                    playe.add(teams.get(i));
                    playe.add(teams2.get(j));
                    String date =  String.valueOf( Integer.parseInt(t.getDate()[0].substring(3,5)) +  days* count);
                    //z  System.out.println("date "+ date);

                    String datem = t.getDate()[0].substring(0,3) + date + t.getDate()[0].substring(5);
                    //Match m = new Match();
                    System.out.println("Now date is " + datem);
                    Match m  = new Match(playe , datem);
                    matches.add( name + " Vs " + name2 );

                    if(t.getMatches() != null){
                    if(!t.getMatches().contains(m))
                        if(addAble){
                        t.addMatch(m);
                        }
                    }

                    count ++;



                }



            }

           Collections.shuffle(matches);



            int c = 0;
            for(int i =0 ; i <columns ; i ++){



                VBox box = new VBox(10);

                box.getChildren().add(new Text("R" + (i+1)));
                for(int j =rows * i ; j < rows * i + rows ; j ++){

                    box.getChildren().add(new Text(matches.get(c)));
                    System.out.println(c);
                    c++;


                }


                h.getChildren().add(box);


            }

            if(addAble){
                Main.addTournment2(t);
            }





           // Collections.shuffle(matches);



            t = Main.tournamentExsist(t.getName());


            ArrayList<Match> m = t.getMatches();
            ArrayList<Integer> scores = new ArrayList<>();
            scores.add(0,0);
            scores.add(1,0);
            scores.add(2,0);
            scores.add(3,0);
            TreeMap<String ,  ArrayList<Integer>> table = new TreeMap<>();

            for(int i = 0 ; i < m.size() ; i ++) {


                if (m.get(i).getScore() != null) {
                    if (m.get(i).getScore()[0] > m.get(i).getScore()[1]) {

                        Participant p1 = m.get(i).getTeams().get(0);
                        Participant p2 = m.get(i).getTeams().get(1);
                        if (t.isIndv()) {


                            return;
                        } else {
                            Team team1 = (Team) p1;
                            Team team2 = (Team) p2;

                            if (table.get(team1.getName()) == null) {

                                ArrayList<Integer> s = new ArrayList<>();
                                s.add(0, 0);
                                s.add(1, 0);
                                s.add(2, 0);
                                s.add(3, 0);

                                table.put(team1.getName(), s);

                            }

                            if (table.get(team2.getName()) == null) {
                                ArrayList<Integer> s = new ArrayList<>();
                                s.add(0, 0);
                                s.add(1, 0);
                                s.add(2, 0);

                                s.add(3, 0);
                                table.put(team2.getName(), s);
                            }
                            ArrayList<Integer> scor = table.get(team1.getName());
                            ArrayList<Integer> scor2 = table.get(team2.getName());


                            scor.set(0, scor.get(0) + 1);
                            scor.set(3, scor.get(3) + 3);
                            table.put(team1.getName(), scor);
                            scor2.set(1, scor2.get(1) + 1);
                            table.put(team2.getName(), scor2);
                        }


                    }


                    else if (m.get(i).getScore()[1] > m.get(i).getScore()[0]){


                        Participant p1 = m.get(i).getTeams().get(0);
                        Participant p2 = m.get(i).getTeams().get(1);
                        if (t.isIndv()) {



                        } else {
                            Team team1 = (Team) p1;
                            Team team2 = (Team) p2;

                            if (table.get(team1.getName()) == null) {

                                ArrayList<Integer> s = new ArrayList<>();
                                s.add(0, 0);
                                s.add(1, 0);
                                s.add(2, 0);
                                s.add(3, 0);

                                table.put(team1.getName(), s);

                            }

                            if (table.get(team2.getName()) == null) {
                                ArrayList<Integer> s = new ArrayList<>();
                                s.add(0, 0);
                                s.add(1, 0);
                                s.add(2, 0);

                                s.add(3, 0);
                                table.put(team2.getName(), s);
                            }
                            ArrayList<Integer> scor = table.get(team1.getName());
                            ArrayList<Integer> scor2 = table.get(team2.getName());


                            scor2.set(0, scor.get(0) + 1);
                            scor2.set(3, scor.get(3) + 3);
                            table.put(team1.getName(), scor);
                            scor.set(1, scor2.get(1) + 1);
                            table.put(team2.getName(), scor2);
                        }











                    }

                    else {

                        Participant p1 = m.get(i).getTeams().get(0);
                        Participant p2 = m.get(i).getTeams().get(1);


                        if (t.isIndv()) {


                        } else {
                            Team team1 = (Team) p1;
                            Team team2 = (Team) p2;

                            if (table.get(team1.getName()) == null) {

                                ArrayList<Integer> s = new ArrayList<>();
                                s.add(0, 0);
                                s.add(1, 0);
                                s.add(2, 0);
                                s.add(3, 0);


                                table.put(team1.getName(), s);

                            }

                            if (table.get(team2.getName()) == null) {
                                ArrayList<Integer> s = new ArrayList<>();
                                s.add(0, 0);
                                s.add(1, 0);
                                s.add(2, 0);
                                s.add(3, 0);


                                table.put(team2.getName(), s);
                            }
                            ArrayList<Integer> scor = table.get(team1.getName());
                            ArrayList<Integer> scor2 = table.get(team2.getName());


                            scor.set(2, scor.get(2) + 1);
                            scor.set(3, scor.get(3) + 1);

                            table.put(team1.getName(), scor);

                            scor2.set(2, scor2.get(2) + 1);
                            scor2.set(3, scor2.get(3) + 1);
                            table.put(team2.getName(), scor2);


                        }

                    }


                }
            }


            System.out.println(table);


            VBox team = new VBox(10);
            team.getChildren().add( new  Text(" Team "));

            VBox wins = new VBox(10);
            wins.getChildren().add( new  Text(" Wins "));

            VBox losses = new VBox(10);
            losses.getChildren().add( new  Text(" losses "));


            VBox draws = new VBox(10);
            draws.getChildren().add( new  Text(" draws "));

            Set<String> keys = table.keySet();


            String winner = "" ;






            int points=0 ;
            for (String key : keys) {

                winner = key;
                ArrayList<Integer > s = table.get(key);

                //System.out.println(key);
                team.getChildren().add(new Text(key));
                wins.getChildren().add(new Text(String.valueOf(s.get(0))));
                losses.getChildren().add(new Text(String.valueOf(s.get(1))));
                draws.getChildren().add(new Text(String.valueOf(s.get(2))));

                points = s.get(3);



                break;
            }




            int i =0 ;

            for (String key : keys) {

                System.out.println(key);
                if(i != 0 ) {
                    ArrayList<Integer> s = table.get(key);
                    //System.out.println(key);
                    team.getChildren().add(new Text(key));
                    wins.getChildren().add(new Text(String.valueOf(s.get(0))));
                    losses.getChildren().add(new Text(String.valueOf(s.get(1))));
                    draws.getChildren().add(new Text(String.valueOf(s.get(2))));


                    if (s.get(3) > points) {
                        winner = key;
                    } else if (s.get(3) == points) {
                        winner = winner + "," + key;
                    }



                }
                i++;
            }

            System.out.println("Winners" + winner);

            if(!winner.contains(",")){

                winn = winner;


            }
            else{


                String[] ts = winner.split(",");
                String team1=ts[0];
                String team2= ts[1];

                Match  ma = new Match();
                for(int j=0; j<m.size();j++){
                    //get the match between the two teams, lets call it ma

                    if(m.get(i).getTeams().get(0).getName().equals(team1) || m.get(j).getTeams().get(1).getName().equals(team1)){
                        if(m.get(j).getTeams().get(0).getName().equals(team2) || m.get(j).getTeams().get(1).getName().equals(team2)){

                            ma = m.get(j);
                        }

                    }

                }
                if(ma.getScore()[0] >ma.getScore()[1] ){




                    Alert alert = new Alert(Alert.AlertType.WARNING);

                    alert.setContentText(" Winner " +  ma.getTeams().get(0));
                    alert.showAndWait();
                    return;




                }
                if(ma.getScore()[0] <ma.getScore()[1]){
                    Alert alert = new Alert(Alert.AlertType.WARNING);



                    alert.setContentText(" Winner " +  ma.getTeams().get(1));
                    alert.showAndWait();
                    return;
                }
                int t1wins= table.get(team1).get(0);
                int t2wins= table.get(team2).get(0);

                if(t1wins>t2wins){
                    Alert alert = new Alert(Alert.AlertType.WARNING);

                    alert.setContentText(" Winner " +  ma.getTeams().get(0));
                    alert.showAndWait();
                    return;
                }
                if(t1wins<t2wins){
                    Alert alert = new Alert(Alert.AlertType.WARNING);



                    alert.setContentText(" Winner " +  ma.getTeams().get(1));
                    alert.showAndWait();
                    return;
                }



                int t1goals=0;
                int t2goals=0;
                int resevt1goals=0;
                int resevt2goals=0;


                Alert alert1 = new Alert(Alert.AlertType.INFORMATION);

                DialogPane dialogPane = alert1.getDialogPane();
                dialogPane.setHeaderText("goals1, goals2,resevt1goals,resevt2goals");
                dialogPane.setContentText("goals1, goals2,resevt1goals,resevt2goals");
                TextField inputField = new TextField();
                dialogPane.setContent(inputField);

                Optional<ButtonType> re = alert1.showAndWait();

                if (re.get() == ButtonType.OK) {


                        // System.out.println("e1");
                        String[] input = inputField.getText().split(",");

                    t1goals = Integer.parseInt(input[0]);
                    t2goals = Integer.parseInt(input[1]);
                    resevt1goals = Integer.parseInt(input[2]);
                    resevt2goals=  Integer.parseInt(input[3]);



                }
            if(t1goals>t2goals){
                Alert alert = new Alert(Alert.AlertType.WARNING);



                alert.setContentText(" Winner " +  ma.getTeams().get(0));
                alert.showAndWait();
                return;
            }
            if(t1goals<t2goals){
                Alert alert = new Alert(Alert.AlertType.WARNING);



                alert.setContentText(" Winner " +  ma.getTeams().get(1));
                alert.showAndWait();
                return;
            }
            if(resevt1goals>resevt2goals){
                Alert alert = new Alert(Alert.AlertType.WARNING);



                alert.setContentText(" Winner " +  ma.getTeams().get(1));
                alert.showAndWait();
                return;
            }
            if(resevt1goals<resevt2goals){
                Alert alert = new Alert(Alert.AlertType.WARNING);



                alert.setContentText(" Winner " +  ma.getTeams().get(0));
                alert.showAndWait();
                return;
            }
            else{
                Alert alert = new Alert(Alert.AlertType.WARNING);



                alert.setContentText(" There are two winner");
                alert.showAndWait();
                return;
            }















        }









            h2.getChildren().add(team);
            h2.getChildren().add(wins);
            h2.getChildren().add(losses);
            h2.getChildren().add(draws);









        }





}

    @FXML
    protected void getWinner() {

        Alert alert = new Alert(Alert.AlertType.WARNING);

        alert.setTitle(" Tournment: " + t.getName());
        alert.setHeaderText(" The current winner of this tournment is " + winn);
        alert.setContentText(" To get the final winner, fill all the scores ");
        alert.showAndWait();
    }
}

