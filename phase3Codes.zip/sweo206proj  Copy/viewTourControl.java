package sweo206proj;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class viewTourControl {

    @FXML
    TextField f1;
    @FXML
    TextField f2;
    @FXML
    TextField f3;


    @FXML
    VBox v1;
    @FXML
    VBox v2;
    @FXML
    VBox v3;

    @FXML
    Pane pane;
    static Pane holder;
    static Tournament t = null;



    @FXML
    public void stop() throws IOException{
        t.setReg(false);

    }

    @FXML
    public void initialize() throws IOException {
        File file = new File("C:\\Users\\ggfor\\IdeaProjects\\sweo206Proj\\src\\main\\java\\com\\example\\sweo206proj\\bro.dat");


        holder = pane;
        if (file.exists()) {


            try (ObjectInputStream oos = new ObjectInputStream(new FileInputStream(file))) {

                while (true) {

                    Tournament tournament = (Tournament) oos.readObject();


                    LocalDate today = LocalDate.now();
                    DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("MM/dd/yyyy");
                    String formattedDate = today.format(formatter1);

                  //  LocalDate tourDate = LocalDate.parse(tournament.getDate()[0],formatter1);

                    String r = tournament.getDate()[1];
                    LocalDate tourDate2 = LocalDate.parse(r,formatter1);

                    String r1 = tournament.getDate()[0];
                    LocalDate tourDate= LocalDate.parse(r1,formatter1);



                    if(tournament.getDate()[0].equals(formattedDate)  ){
                        Button b1 = new Button(tournament.toString());
                        v2.getChildren().add(b1);
                        b1.setOnAction(event -> {

                            holder.setDisable(false);
                            holder.setVisible(true);
                            t = tournament;

                        });

                    }

                    else if(tourDate.isBefore(today) && tourDate2.isAfter(today)){

                        Button b1 = new Button(tournament.toString());
                        v2.getChildren().add(b1);
                        b1.setOnAction(event -> {

                            holder.setDisable(false);
                            holder.setVisible(true);
                            t = tournament;

                        });


                    }
                    else if (tourDate2.isBefore(today)){
                        v1.getChildren().add(new Text(tournament.toString()));


                    }else{


                        Button b1 = new Button(tournament.toString());
                        v3.getChildren().add(b1);

                        b1.setOnAction(event -> {

                            holder.setDisable(false);
                            holder.setVisible(true);
                            t = tournament;

                        });




                    }



                }


            }
            catch (EOFException e) {

                return;


                //System.out.println("ed");

            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }

        }



    }


    @FXML
    protected void backAct(ActionEvent event) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("s2Admin.fxml"));


            Node node = (Node) event.getSource();

            Window win = ((Scene) node.getScene()) .getWindow();
            if (win != null) {
                Scene scene = win.getScene();
                if (scene != null) {
                    javafx.stage.Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    FXMLLoader fxmlLoader2 = new FXMLLoader(Main.class.getResource("s2Admin.fxml"));



                    Scene scene2 = new Scene(fxmlLoader2.load(), 900, 600);
                    stage.setScene(scene2);
                }
            }}


    @FXML
    public void save() throws IOException{

        String name = f2.getText();

        System.out.println("ent");
        if(t == null)
            return;
        t.setName(name);
        Main.addTournment2(t);




    }

    @FXML

    public void table(ActionEvent event) throws IOException {


        System.out.println("emt?");
        String days = f3.getText();



        ArrayList<Match> mScores = new ArrayList<>();


      //  for (int i = 0; i < t.getMatches().size(); i++) {
      //      if (t.getMatches().get(i).score != null)
               // mScores.add(t.getMatches().get(i));

      //  }

     //   if (mScores.size() == 0) {

            //alert no table
       // } else {


            if (t instanceof RoundRobin) {
                roundCont.t = t;
                roundCont.days = Integer.parseInt(days);

                int columns = t.getPlayers().size() -1;
                if(columns <= 0){
                    return ;
                }
                int rows = t.getMatches().size() / (columns );

                //view



                Map<Participant, ArrayList<String>> map = new HashMap<>();

                ArrayList<Participant> teams = t.getPlayers();
                ArrayList<Participant> teams2 = t.getPlayers();


                ArrayList<String> matches = new ArrayList<>();
                for(int i = 0 ; i < teams.size() ; i ++){

                    for(int j =(i+1) ;j < (teams.size()) ; j ++){

                        if(!teams.get(i).equals(teams2.get(j))){
                            String name ="";
                            String name2 = "";
                            if(teams.get(i) instanceof Team){
                                name = ((Team)teams.get(i)).getName();
                                name2 = ((Team)teams2.get(i)).getName();

                            }
                            else{
                                name = String.valueOf(((Student)teams.get(i)).getUserName());
                                name2 = String.valueOf(((Student)teams2.get(i)).getUserName());
                            }
                            matches.add( name + " Vs " + name2 );

                        }

                    }



                }



                Collections.shuffle(matches);


                Node node = (Node) event.getSource();

                Window win = ((Scene) node.getScene()) .getWindow();
                if (win != null) {
                    Scene scene = win.getScene();
                    if (scene != null) {
                        javafx.stage.Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                        FXMLLoader fxmlLoader2 = new FXMLLoader(Main.class.getResource("roundScene.fxml"));



                        Scene scene2 = new Scene(fxmlLoader2.load(), 900, 600);
                        stage.setScene(scene2);
                    }
                }








            }
            else {

                elmcont.t = t;
                elmcont.days = Integer.parseInt(days);



                Node node = (Node) event.getSource();

                Window win = ((Scene) node.getScene()) .getWindow();
                if (win != null) {
                    Scene scene = win.getScene();
                    if (scene != null) {
                        javafx.stage.Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                        FXMLLoader fxmlLoader2 = new FXMLLoader(Main.class.getResource("elmSce.fxml"));



                        Scene scene2 = new Scene(fxmlLoader2.load(), 900, 600);
                        stage.setScene(scene2);
                    }
                }



               // System.out.println("Tour ent");
                //int number = mScores
            }


        }
    }
//}
