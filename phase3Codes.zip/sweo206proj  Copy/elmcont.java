package sweo206proj;

import javafx.fxml.FXML;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;



public class elmcont {

    static Tournament t ;
    @FXML
    HBox h ;
    static  int days;

    public void initialize() throws IOException {

        int coulmns =0;



        int num = t.getPlayers().size() ;

        boolean addAble = t.getMatches().size() == 0;

        ArrayList<VBox> cols = new ArrayList<>();
        int c = 1;
        while(num >1){


            num =num/2;
            coulmns ++;
            cols.add(new VBox(new Text(String.valueOf(c))));
            c++;
        }
        System.out.println("Columns are" + coulmns);

        t.getMatches().clear();

        ArrayList<Match> ms = new ArrayList<>();
        int count = 0;
        if(coulmns >=1){
            VBox box =cols.get(0);
            box.getChildren().add(new Text("-- First Matches-- "));

            box.getChildren().add(new Text("\n\n"));



            int team  =0 ;

           ArrayList<Participant>  players = t.getPlayers();
           if(addAble)
               Collections.shuffle(players);




            for(int i =0 ; i <players.size()/2; i ++ ){
                Participant p1 = players.get(team);
                Participant p2 = players.get(team+1);

                System.out.println(p1.getName() +" VS " + p2.getName());
                team  = team +2;
                // create matches with date
                // until there are more columns add half of the previous teams and so on


                box.getChildren().add(new Text(p1.getName() ));

                box.getChildren().add(new Text( "  VS "));
                box.getChildren().add(new Text(p2.getName() ));
                box.getChildren().add(new Text( "\n"));
                ArrayList<Participant> ps = new ArrayList<>();
                ps.add(p1);
                ps.add(p2);


                String date =  String.valueOf( Integer.parseInt(t.getDate()[0].substring(3,5)) +  days* count);

                //z  System.out.println("date "+ date);
                String datem = t.getDate()[0].substring(0,3) + date + t.getDate()[0].substring(5);
                Match m = new Match(ps , datem);

                ms.add(m);
                if(t.getMatches() != null){
                    if(!t.getMatches().contains(m)){
                        if(addAble)
                            t.addMatch(m);

                    }
                }

                count ++;

            }

            if(addAble){
                Main.addTournment2(t);
            }

            h.getChildren().add(box);

        }
        else{
            return;
        }



        //check salfh match
        // add to vboxes
        // test afetr fucos
        // add tournment
        //get winner

        t = Main.tournamentExsist(t.getName());
        ArrayList<Match> ms2 = t.getMatches();
        System.out.println(ms2.get(1).getTeams().get(0).getName());
        for(int i = 0 ; i < coulmns ; i ++){

            System.out.println("Ith+ " + i );
            int mcount = 0;
            VBox col = new VBox();
            ArrayList<Match> cur = new ArrayList<>();
            for(int j = 0 ; j < ms2.size()/2 ; j ++){
                System.out.println("Entter");
                Match m1 = ms2.get(mcount);
                Match m2 = ms2.get(mcount+1);

                if(m1.getScore() != null && m2.getScore() != null) {
                    Participant p1 = m1.getWinner();
                    Participant p2 = m2.getWinner();



                  //  System.out.println(p1.getName() + " VS " + p2.getName());


                    col.getChildren().add(new Text("\n\n\n\n\n"));

                    col.getChildren().add( new Text(p1.getName() + " VS " + p2.getName()));

                    System.out.println(i);
                    col.getChildren().add(new Text("\n\n"));
                    ArrayList<Participant> ar = new ArrayList<>();
                    ar.add(p1);
                    ar.add(p2);
                    String date = String.valueOf(Integer.parseInt(t.getDate()[0].substring(3, 5)) + days * count);

                    //z  System.out.println("date "+ date);
                    String datem = t.getDate()[0].substring(0, 3) + date + t.getDate()[0].substring(5);
                    count++;
                    Match match = new Match(ar, datem);
                    cur.add(match);
                    t.getMatches().add(match);
                    if(addAble)
                        Main.addTournment2(t);


                }



                mcount = mcount + 2;
            }
            ms2 = cur;
            h.getChildren().add(col);
            col = new VBox();





        }


    }
}
