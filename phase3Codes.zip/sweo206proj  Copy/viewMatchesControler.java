package sweo206proj;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class viewMatchesControler {

    @FXML
    TextField searchF;

    @FXML
    VBox tableV;

    @FXML
    Pane recordP;

    @FXML
    Pane recordP1;




    @FXML
    Button saveB;

    @FXML
    TextField scoreF;
    @FXML
    TextField scoreF1;

    @FXML
    TextField tournmentF;

    @FXML
    TextField dateF;

    @FXML
    TextField playerF;

    @FXML
    static Button but =null;

    static Pane holder = new Pane();
    static Match match = null;

    static int cnt = 0;
    static Tournament t = null;


    static ArrayList<Match>  mtch = new ArrayList<>();

    static ArrayList<Button>  bts = new ArrayList<>();

    static ArrayList<Tournament>  ts = new ArrayList<>();
    static Button b1 = null;
   //static Rectangle panel;

    @FXML
    public void initialize() throws IOException {
        holder = recordP;

        //System.out.println(holder);


       // System.out.println(holder.getChildren());
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        String formattedDate = today.format(formatter);

        Main.addInfoToList(formattedDate,tableV.getChildren());

       // tableV.getChildren().add(new Button("s"));
       // System.out.println("Today's date: " + formattedDate);


    }
    @FXML
    protected void backAct(ActionEvent event) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("s2Admin.fxml"));


        Node node = (Node) event.getSource();

        Window win = ((Scene) node.getScene()) .getWindow();
        if (win != null) {
            Scene scene = win.getScene();
            if (scene != null) {
                javafx.stage.Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                FXMLLoader fxmlLoader2 = new FXMLLoader(Main.class.getResource("s2Admin.fxml"));



                Scene scene2 = new Scene(fxmlLoader2.load(), 900, 600);
                stage.setScene(scene2);
            }
        }
    }


    public static void makeAct(Button b ,Match m  , Tournament tour, int count){
      //  Button b1 = (Button) tableV.lookup(b.getText());




        but = b;


        bts.add(b);
        ts.add(tour);
        match = m;
        if(mtch != null)
            mtch.add(m);
        else{

        }


        cnt = count;

        b.setOnAction(event -> {



            //b1= b;
            System.out.println("Name is" + tour.getName());
            holder.setDisable(false);
            holder.setVisible(true);



            //recordP.setDisable(false);

        });

    }

    @FXML
    protected  void score() throws IOException {

        if(match == null)
            return;



        File file = new File("C:\\Users\\ggfor\\IdeaProjects\\sweo206Proj\\src\\main\\java\\com\\example\\sweo206proj\\bro.dat");


        match = mtch.get(cnt);
        but = bts.get(cnt);
        t = ts.get(cnt);
        System.out.println("Match is " + match.getTeams().get(0).getName());

        System.out.println(t.getName());

        System.out.println("match " + match.getTeams().get(1).getName());
        String number = scoreF.getText();
        String number2 = scoreF1.getText();

        if(!(number.isEmpty() || number2.isEmpty() ))
        if(Main.isNumber(number, number2)){
            int value = Integer.parseInt(number);
            int value2 = Integer.parseInt(number2);
            int[] ar ={value, value2};









           // System.out.println(t.getMatches().get(0).getScore()[0]);
            //show meesage it has been saved

            System.out.println("Tourns is" + t);
            int indx = but.getText().indexOf("VS");

            but.setText(but.getText().substring(0,indx+8) + " Scores: " + number +" TO  " + number2);
            but.setText(but.getText().substring(0,indx+8) + " Scores: " + number +" TO  " + number2);


            System.out.println(t.getName() + " name");

            match.setScore(ar);
            System.out.println(match.getScore()[0]);


            for(int j = 0 ; j < t.getMatches().size() ; j ++){



                if(t.getMatches().get(j).getTeams().equals(match.getTeams())){

                    System.out.println("Ented? ");
                    t.getMatches().get(j).setScore(match.getScore());

                }
            }


            Main.addTournment2(t);





            holder.setDisable(true);
            holder.setVisible(false);



        }
        else{

            //erro


        }



    }


    @FXML
    protected void addMatch() throws IOException{
        String name =tournmentF.getText();
        String date = dateF.getText();
        String players  = playerF.getText();

        Tournament tour = Main.tournamentExsist(name);
        System.out.println(tour.getMatches());



        String[] playersAr = players.split(",");

        Match match = null;

        Participant p1 = null ;
        Participant p2  = null;

        if(tour.isIndv()){

             p1= Main.searchByUserName(Integer.valueOf(playersAr[0])).getStudent();
             p2= Main.searchByUserName(Integer.valueOf(playersAr[1])).getStudent();


            //match = new Match(students , dates);



        }
        else{
            System.out.println("Ent2?");
            ArrayList<Participant > teams = tour.getPlayers();
            System.out.println("players" + tour.getPlayers());


            for(int i = 0 ; i <teams.size() ; i ++){


                if(((Team)teams.get(i)).getName().equals(playersAr[0])){

                    p1= (Team)teams.get(i);
                }
                else if(((Team)teams.get(i)).getName().equals(playersAr[1])) {

                    p2= (Team)teams.get(i);


                }

            }




        }


        ArrayList<Participant> ps = new ArrayList<>();
        ps.add(p1);
        ps.add(p2);
        Match matchObjs= new Match(ps, date);

        tour.getMatches().add(matchObjs);
       // System.out.println("Which:" + tour.getMatches());
        Main.addTournment2(tour);

        System.out.println("Added");

       // recordP1.setVisible(true);


       // Match match = new Match( dates);



    }


    @FXML
    protected void search() throws IOException {
        String date= searchF.getText();

       // System.out.println(date);
        boolean valid = true;

        if(!date.isEmpty()){
            if(Main.validateDate(date)){

                String date2 = date;
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
                // Parse the start date string into a LocalDate object
                LocalDate parsedStartDate = LocalDate.now();


                // Parse the end date string into a LocalDate object
                LocalDate parsedEndDate = LocalDate.parse(date2, formatter);

                System.out.println(parsedStartDate.isAfter(parsedEndDate));

                //tableV.getChildren().retainAll(new Button("w0fk"));
                    System.out.println("Emt?");
                tableV.getChildren().removeAll(tableV.getChildren());

                Main.addInfoToList(date,tableV.getChildren());}

            else{

                Alert alert = new Alert(Alert.AlertType.WARNING);

                alert.setTitle("Input Error");
                alert.setHeaderText(" The given input is wrong ");
                alert.setContentText("try again");
                alert.showAndWait();
            }


        }
        else{
            Alert alert = new Alert(Alert.AlertType.WARNING);

            alert.setTitle("Empty input");
            alert.setHeaderText(" The filed is empty");
            alert.setContentText("Please try write before pressing subimt");
            alert.showAndWait();
        }





    }





}
