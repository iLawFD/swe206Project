package sweo206proj;

import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.fxml.FXML;
import java.io.IOException;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.IOException;

public class controllerRecord {

    @FXML
    TextField nameF;
    @FXML
    ComboBox<String> typeCB;
    @FXML
    ComboBox<String> isindvCB;
    @FXML
    ComboBox<String> sportgameCB;

    @FXML
    TextField dateF;
    @FXML
    TextField date2F;


    @FXML
    Button backB;
    @FXML
    protected void backAct(ActionEvent event) throws IOException {

        Node node = (Node) event.getSource();

        Window win = ((Scene) node.getScene()) .getWindow();
        if (win != null) {
            Scene scene = win.getScene();
            if (scene != null) {
                javafx.stage.Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                FXMLLoader fxmlLoader2 = new FXMLLoader(Main.class.getResource("s2Admin.fxml"));


                Scene scene2 = new Scene(fxmlLoader2.load(), 900, 600);
                stage.setScene(scene2);
            }
        }






    }

    @FXML
    public void initialize() {

        ObservableList<String> list = FXCollections.observableArrayList();
        Main.addSportsToList(list);
        sportgameCB.setItems(list);


        Text text = new Text("Individual");

        isindvCB.setItems(FXCollections.observableArrayList("Individual", "Teams"));
        typeCB.setItems(FXCollections.observableArrayList("RoundRobin", "Elimination"));


    }



    @FXML
    protected void recordTournment() throws IOException {



        String name = nameF.getText();
        String type = typeCB.getValue();
        String isIndv = isindvCB.getValue();
        String sportName = sportgameCB.getValue();

        String  date1 = dateF.getText();
        String  date2 = date2F.getText();


        boolean notEmpty= Main.emptyInput(name, isIndv , type, sportName, date1 ,date2);
        boolean valid= Main.validInput( isIndv , type, date1 ,date2) ;

        SportGame value = Main.sportExsists(sportName);
        System.out.println(Tournament.validName(name));

         valid= (valid) &&Tournament.validName(name) && (value != null);






        if(notEmpty){

            if(valid){

                String[] dates = {date1, date2};
                boolean isindv = isIndv.equals("Individual");
                if(type.equals("Elimination")){
                   //System.out.println("Added");
                    Tournament tournment = new Elimination(name,value,isindv, dates);
                    System.out.println("yes");
                    if(Main.tournamentExsist(tournment.getName()) == null){
                       // System.out.println("hmm?");
                        Main.addTournment2(tournment);

                        Alert alert = new Alert(Alert.AlertType.INFORMATION);


                        alert.setTitle("Tournment creation");
                        alert.setHeaderText(" The giveb Elimination tournment has been sucessfuly created ");
                        alert.setContentText(" The tournment can be seen and modified in the view Tournment section. Hit the back arrow to go back");
                        alert.showAndWait();


                    }
                    else{

                        System.out.println("ralt");
                        Alert alert = new Alert(Alert.AlertType.ERROR);


                        alert.setTitle("Error");
                        alert.setHeaderText("The given Elimination Tournment already exists ");
                        alert.setContentText(" Please create a tournment with unique parameters");
                        alert.showAndWait();
                    }





                }
                else{

                    Tournament tournment = new RoundRobin(name,value,isindv, dates);

                    if(Main.tournamentExsist(tournment.getName()) == null){

                        Main.addTournment2(tournment);
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Tournment creation");
                        alert.setHeaderText(" The given round robin tournment has been sucessfuly created ");
                        alert.setContentText(" The tournment can be seen and modified in the view Tournment section. Hit the back arrow to go back");
                        alert.showAndWait();



                    }
                    else{

                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Error");
                        alert.setHeaderText("The given RoundRobin Tournment already exists ");
                        alert.setContentText(" Please create a tournment with unique parameters");
                        alert.showAndWait();
                    }


                }












            }
            else{

                Alert alert = new Alert(Alert.AlertType.WARNING);

                alert.setTitle("Input Error");
                alert.setHeaderText("One more or more of the given input is wrong! ");
                alert.setContentText("Please note that date must be in the format of MM/DD/YYYY and tournemnt name should not start with number and should consist of 8 charcters or less");
                alert.showAndWait();
            }


        }
        else{
            Alert alert = new Alert(Alert.AlertType.ERROR);

            alert.setTitle("Input Error");
            alert.setHeaderText("One or more of the fields are empty! ");
            alert.setContentText("Please fill all of the information before pressing create account");
            alert.showAndWait();
        }


















    }





}
