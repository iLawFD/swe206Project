package sweo206proj;

import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

public class MatchHolder extends HBox {
    Match match;
    Button recordScore;
    boolean filled= true;

    MatchHolder(Match match, Button recordScore){
        this.match = match;
        this.recordScore = recordScore;
        this.getChildren().add(new Text(match.toString()));
        this.getChildren().add(recordScore);

    }




}
